-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2025 at 04:08 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `beaukind`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `Cart Id` int(11) NOT NULL,
  `Product Id` int(11) NOT NULL,
  `Customer Id` int(11) NOT NULL,
  `Quentity` int(11) NOT NULL,
  `Price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`Cart Id`, `Product Id`, `Customer Id`, `Quentity`, `Price`) VALUES
(2, 15, 1, 1, 600),
(3, 16, 1, 6, 400),
(4, 11, 1, 1, 300),
(5, 12, 1, 1, 500);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `User Id` int(11) NOT NULL,
  `First Name` varchar(50) NOT NULL,
  `Last Name` varchar(50) NOT NULL,
  `Birthdate` date NOT NULL,
  `Phone No` int(10) NOT NULL,
  `Email Id` varchar(50) NOT NULL,
  `Address One` text NOT NULL,
  `Address Two` text NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `otp_expiry` datetime DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`User Id`, `First Name`, `Last Name`, `Birthdate`, `Phone No`, `Email Id`, `Address One`, `Address Two`, `password`, `otp`, `otp_expiry`, `email_verified`, `created_at`) VALUES
(1, 'Mihir', 'Valand', '2025-06-18', 1234567890, 'mihir@gamil.com', 'add1', 'add2', '123456', NULL, NULL, 0, '2025-06-12 15:32:54');

-- --------------------------------------------------------

--
-- Table structure for table `howitworks`
--

CREATE TABLE `howitworks` (
  `HowItWork Id` int(11) NOT NULL,
  `How Work Img` varchar(255) NOT NULL,
  `How Work Title` varchar(50) NOT NULL,
  `How Work Desc` varchar(200) NOT NULL,
  `Product Id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order customer`
--

CREATE TABLE `order customer` (
  `Order Id` int(11) NOT NULL,
  `Product Id` int(11) NOT NULL,
  `Customer Id` int(11) NOT NULL,
  `Order Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Quantity` int(11) NOT NULL,
  `Delivery Date` date NOT NULL,
  `Payment Status` varchar(50) NOT NULL,
  `Payment Method` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product Id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Description` text NOT NULL,
  `Quanity` varchar(50) NOT NULL,
  `Ingredients` text NOT NULL,
  `How to use` text NOT NULL,
  `proimg1` varchar(255) NOT NULL,
  `proimg2` varchar(255) NOT NULL,
  `proimg3` varchar(255) NOT NULL,
  `proimg4` varchar(255) NOT NULL,
  `proimg5` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product Id`, `Name`, `Price`, `Description`, `Quanity`, `Ingredients`, `How to use`, `proimg1`, `proimg2`, `proimg3`, `proimg4`, `proimg5`) VALUES
(11, 'Moisturizer', 300.00, 'A gentle, hydrating moisturizer that softens and refreshes skin. Perfect for daily use and all skin types.\n\n', '75 g / 2.65 fl.oz.', 'Apply to clean, dry skin. Gently massage into face and neck using upward strokes. Use morning and night for best results. Avoid contact with eyes.', '30', 'image/ProductImges/Rectangle 97.png', 'image/ProductImges/Rectangle 99.png', 'image/ProductImges/Rectangle 96.png', 'image/ProductImges/Rectangle 98.png', 'image/ProductImges/Rectangle 95.png'),
(12, 'Sunscreen', 500.00, 'Lightweight, non-greasy sunscreen that protects skin from harmful UVA/UVB rays and prevents premature aging.', '50ml / 1.69 oz.', 'Apply generously to cleansed face and neck 15 minutes before sun exposure. Reapply every 2 hours, especially after swimming or sweating. Suitable for daily use. Use as the last step in your skincare routine before makeup.Aqua (Water), Cocamidopropyl Betaine, Glycerin, Aloe Vera, Green Tea Extract, Salicylic Acid, Niacinamide, Allantoin, Panthenol, Phenoxyethanol, Fragrance.\n\nWater/Aqua, Sodium Lauroyl Sarcosinate, Cocamidopropyl Betaine, Decyl Glucoside, Coco Glucoside, Glycerin, Propanediol, Glutathione, Kojic Acid, Niacinamide, Salicylic Acid, Panthenol, Sodium PCA, Alpha Arbutin Sodium Hydroxide, Phenoxyethanol, Ethylhexyl glycerin, Allantoin.\n', 'Apply a small amount of face wash to wet skin. Gently massage in circular motions to cleanse. Rinse thoroughly with water. Use daily for best results.\n For external use only. If contact occurs, rinse thoroughly with clean water. Avoid contact with eyes. In case of irritation, discontinue use and consult a dermatologist. Keep out of reach of children. \n', 'image/ProductImges/Rectangle 96.png', 'image/ProductImges/Rectangle 95.png', 'image/ProductImges/Rectangle 97.png', 'image/ProductImges/Rectangle 99.png', 'image/ProductImges/Rectangle 97.png'),
(14, 'Facewash', 20.00, 'Gentle foaming cleanser that removes dirt, oil, and impurities without stripping skin\'s natural moisture.\n\n', '100 ml / 3.4 fl. oz.', 'Water/Aqua, Sodium Lauroyl Sarcosinate, Cocamidopropyl Betaine, Decyl Glucoside, Coco Glucoside, Glycerin, Propanediol, Glutathione, Kojic Acid, Niacinamide, Salicylic Acid, Panthenol, Sodium PCA, Alpha Arbutin Sodium Hydroxide, Phenoxyethanol, Ethylhexyl glycerin, Allantoin.\n', 'Apply a small amount of face wash to wet skin. Gently massage in circular motions to cleanse. Rinse thoroughly with water. Use daily for best results.\n For external use only. If contact occurs, rinse thoroughly with clean water. Avoid contact with eyes. In case of irritation, discontinue use and consult a dermatologist. Keep out of reach of children. \n', 'image/ProductImges/Rectangle 80.png', 'image/ProductImges/Rectangle 96.png', 'image/ProductImges/Rectangle 97.png', 'image/ProductImges/Rectangle 98.png', 'image/ProductImges/Rectangle 99.png'),
(15, 'Peeling Solution', 600.00, 'A powerful exfoliating solution that removes dead skin cells, unclogs pores, and boosts skin radiance.', '30ml / 1.01 fl. oz.', 'Aqua, Glycolic Acid, Lactic Acid, Propylene Glycol, Gluconolactone, Sodium Hydroxide, Salicylic Acid, Propanediol, Aloe barbadensis Miller (Aloe vera) Extract, Curcuma Longa (Turmeric) Root Extract, Triethanolamine, Sodium Hyaluronate, Phenoxyethanol, Ethylhexyl glycerin, Hydroxyethyl cellulose, Xanthan Gum.', 'Apply a thin layer to clean, dry skin. Leave for 10-15 minutes. Rinse thoroughly with lukewarm water. Use once or twice a week. Do not use on broken or irritated skin. Always follow with sunscreen during the day.\r\n For external use only. Avoid direct contact with eyes. If irritation or discomfort occurs, rinse immediately and discontinue use and consult a dermatologist. Keep out of reach of children.', 'image/ProductImges/Rectangle 95.png', 'image/ProductImges/Rectangle 98.png', 'image/ProductImges/Rectangle 98.png', 'image/ProductImges/Rectangle 98.png', 'image/ProductImges/Rectangle 96.png'),
(16, 'Face  Serum', 400.00, 'A concentrated serum that hydrates, brightens, and improves skin texture for a healthy glow.', '30 ml / 1.01 fl. oz.', 'Aqua, Ethyl Ascorbic Acid, Ascorbic Glucoside, Sodium Ascorbic Acid, Niacinamide, Glutathione, Glycerin, Propylene Glycol, Alpha Arbutin, Lactic Acid, Sodium Hyaluronate, Triethanolamine, Xanthan Gum, Lecithin, Phenoxyethanol, Ethylhexyl glycerin.', 'After cleansing, apply a few drops of serum to the face. Gently massage until absorbed. For best results, use twice daily.\r\n For external use only. Avoid contact with eyes. If irritation occurs, discontinue use and consult a dermatologist. Keep out of reach of children. If contact occurs, rinse thoroughly with clean water.', 'image/ProductImges/Rectangle 98.png', 'image/ProductImges/Rectangle 80.png', 'image/ProductImges/Rectangle 96.png', 'image/ProductImges/Rectangle 98.png', 'image/ProductImges/Rectangle 99.png');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `review_text` text NOT NULL,
  `review_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`Cart Id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`User Id`);

--
-- Indexes for table `howitworks`
--
ALTER TABLE `howitworks`
  ADD PRIMARY KEY (`HowItWork Id`),
  ADD KEY `Product Id` (`Product Id`);

--
-- Indexes for table `order customer`
--
ALTER TABLE `order customer`
  ADD PRIMARY KEY (`Order Id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product Id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `Cart Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `User Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `howitworks`
--
ALTER TABLE `howitworks`
  MODIFY `HowItWork Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order customer`
--
ALTER TABLE `order customer`
  MODIFY `Order Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Product Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `howitworks`
--
ALTER TABLE `howitworks`
  ADD CONSTRAINT `howitworks_ibfk_1` FOREIGN KEY (`Product Id`) REFERENCES `product` (`Product Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
