<!-- Scrolling announcement bar -->
        <div class="announcement">
            <div class="marquee-container">
                <div class="marquee-content">
                    &#9733; 20% Discount on all products for first orders &#9733;
                    20% Discount on all products for first orders &#9733;
                    20% Discount on all products for first orders &#9733;
                </div>
            </div>
        </div> 
 
<!-- Main navigation bar -->
<nav class="navbar">
    <div class="logo"><img src="img/beaukind logo nav.svg" alt=""></div>
    <ul class="nav-links">
        <li><a href="#section1" class="nav-link">Home</a></li>
        <li><a href="#section2" class="nav-link">About</a></li>
        <li><a href="#section3" class="nav-link">Products</a></li>
        <li><a href="#section4" class="nav-link">Contact</a></li>
    </ul>
    <div class="icons">
        <img src="img/nav-user.svg" alt="user" data-bs-toggle="modal" data-bs-target="#exampleModalToggle">
        
        <a href="cartpage.php"><img src="img/nav-shopping-cart.svg" alt="cart"></a>
        <span id="cart-nav-qty"></span>
    </div>
</nav>

<!-- Login Modal -->
<div class="modal fade" id="exampleModalToggle" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5">Login</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="loginform">
                    <div class="mb-3">
                        <label for="contactLogin" class="form-label">Eamil</label>
                        <input type="email" class="form-control" id="emailLogin"
                            placeholder="Enter your Email id">
                    </div>
                    <div class="mb-3">
                        <label for="otpLogin" class="form-label">Password</label>
                        <input type="password" class="form-control" id="PasswordLogin" placeholder="Enter Password">
                    </div>
                    <div class="mb-3 d-flex justify-content-between">
                        <span class="form-label">Didn’t receive?</span>
                        <a href="#">Send again</a>
                    </div>
                    <button type="button" class="btn1 w-100 mb-3" id="loginBtn">Continue</button>
                    <button type="submit" class="btn2 w-100 mb-3">Login with Google
                        <img src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg"
                            class="googleicon" alt="Google">
                    </button>
                    <div class="text-center">
                        <label>Don't have an account? <a href="#" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle2">Sign up</a></label>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Signup Modal -->
<div class="modal fade" id="exampleModalToggle2" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5">Sign Up</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="mb-3">
                        <label for="signupName" class="form-label">Name</label>
                        <input type="text" class="form-control" id="signupName" placeholder="Enter your name">
                    </div>
                    <div class="mb-3">
                        <label for="signupEmail" class="form-label">Email</label>
                        <input type="email" class="form-control" id="signupEmail"
                            placeholder="Enter your email">
                    </div>
                    <div class="mb-3">
                        <label for="signupPassword" class="form-label">Passowrd</label>
                        <input type="text" class="form-control" id="signupPassword"
                            placeholder="Enter your Password">
                    </div>
                    <div class="mb-3">
                        <label for="signupCPass" class="form-label">Conform Password</label>
                        <input type="text" class="form-control" id="signupCPass" placeholder="Enter your Password">
                    </div>
                    <div class="mb-3 d-flex justify-content-between">
                        <span class="form-label">Didn’t receive?</span>
                        <a href="#">Send again</a>
                    </div>
                    <div class="mb-3">
                        <input type="checkbox" id="termsCheck">
                        <label for="termsCheck">By signing up I agree to the <a href="#">terms &
                                conditions</a></label>
                    </div>
                    <button type="button" class="btn1 w-100 mb-3" id="signupBtn">Continue</button>
                    <button type="submit" class="btn2 w-100 mb-3">Login with Google
                        <img src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg"
                            class="googleicon" alt="Google">
                    </button>
                    <div class="text-center">
                        <label>Already have an account? <a href="#" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle">Login</a></label>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>