<?php
// auth/signup.php
session_start();
require_once '../admin/db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Sanitize and validate input
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
// $birthdate = $_POST['birthdate'] ?? '';
// $address1 = trim($_POST['address1'] ?? '');
// $address2 = trim($_POST['address2'] ?? '');
$password = $_POST['password'] ?? '';

// Validation
$errors = [];

// Name validation
if (empty($name) || strlen($name) < 2) {
    $errors[] = 'Name must be at least 2 characters long';
}

// Email validation
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Please enter a valid email address';
}

// Phone validation
if (empty($phone) || !preg_match('/^\d{10}$/', $phone)) {
    $errors[] = 'Phone number must be exactly 10 digits';
}

// // Birthdate validation
// if (empty($birthdate)) {
//     $errors[] = 'Birth date is required';
// } else {
//     $birth = new DateTime($birthdate);
//     $today = new DateTime();
//     $age = $today->diff($birth)->y;
//     if ($age < 13) {
//         $errors[] = 'You must be at least 13 years old';
//     }
//     if ($birth > $today) {
//         $errors[] = 'Birth date cannot be in the future';
//     }
// }

// // Address validation
// if (empty($address1)) {
//     $errors[] = 'Address is required';
// }

// Password validation
if (empty($password) || strlen($password) < 6) {
    $errors[] = 'Password must be at least 6 characters long';
}

if (!empty($errors)) {
    echo json_encode(['success' => false, 'message' => implode(', ', $errors)]);
    exit;
}

try {
    // Check if email already exists
    $stmt = $conn->prepare("SELECT `User Id` FROM customer WHERE `Email Id` = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Email address is already registered']);
        exit;
    }

    // Check if phone number already exists
    $stmt = $conn->prepare("SELECT `User Id` FROM customer WHERE `Phone Number` = ?");
    $stmt->bind_param("s", $phone);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Phone number is already registered']);
        exit;
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Combine address fields
    // $fullAddress = $address1;
    // if (!empty($address2)) {
    //     $fullAddress .= ', ' . $address2;
    // }

    // Insert new user
    $stmt = $conn->prepare("INSERT INTO customer (`Name`, `Email Id`, `Phone Number`, `Password`) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $phone, $hashedPassword);

    if ($stmt->execute()) {
        $userId = $conn->insert_id;

        // Set session variables for automatic login
        $_SESSION['user_id'] = $userId;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_email'] = $email;
        $_SESSION['logged_in'] = true;

        echo json_encode([
            'success' => true,
            'message' => 'Account created successfully! You are now logged in.',
            'redirect' => '../index.php' // or wherever you want to redirect
        ]);
    } else {
        throw new Exception('Failed to create account');
    }
} catch (Exception $e) {
    error_log("Signup error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred during registration. Please try again.']);
} finally {
    if (isset($stmt)) {
        $stmt->close();
    }
    $conn->close();
}
