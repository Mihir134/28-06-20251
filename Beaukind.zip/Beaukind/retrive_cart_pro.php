<?php
include('admin/db.php');
session_start();
$customer_id = $_SESSION['customer_id'];
// SQL with JOIN: get cart items + product details
$sql = "SELECT 
            cart.*, 
            product.`Name` AS product_name,
            product.`Price`,            
            product.`proimg1`
        FROM `cart` 
        JOIN `product` ON cart.`Product Id` = product.`Product Id`
        WHERE cart.`Customer Id` = $customer_id";

$result = mysqli_query($conn, $sql);

$cart_total_pro = mysqli_num_rows($result);

// echo json_encode(["cartTotalPro" => $cart_total_pro]);


$subtotal = 0;

echo "<div class='cart-container'>
    <div class='cart-products'>
        <div class='pro-of-cart make-it-hide'>
            <div class='cart-proimg'>
                <p>Product</p>
            </div>
            <div class='cart-pro-detail'>
                <p>Price</p>
                <p>Quantity</p>
                <p>Total</p>
            </div>
        </div>";




while ($row = mysqli_fetch_assoc($result)) {
    $productId = $row['Product Id'];
    $qty = $row['Quentity'];
    $price = $row['Price'];
    $productName = $row['product_name'];
    $image = $row['proimg1'];
    $qtyTotal = $price * $qty;
    $subtotal += $qtyTotal;

    echo "
        <div class='pro-of-cart'>
            <div class='cart-proimg'>
                <button onclick='RemoveFromCart({$productId})'><img src='img/cross X.svg' alt=''></button>
                <img src='admin/{$image}' alt='product'>
                <p>{$productName}</p>
            </div>
            <div class='cart-pro-detail'>
                <p>Rs.{$price}/-</p>
                <form class='product-quentity'>
                    <div class='propage-pro-quentity'>
                        <button type='button' class='propage-qty-btn' onclick='decrease({$productId}, {$price})'>
                            <img src='img/square-subtract.svg' alt='-'>
                        </button>
                        <input type='number' id='qty-{$productId}' class='cart-pro-qty-btn' value='{$qty}' readonly min='1' max='10'>
                        <button type='button' class='propage-qty-btn' onclick='increase({$productId}, {$price})'>
                            <img src='img/square-plus.svg' alt='+'>
                        </button>
                    </div>
                </form>
                <p>Rs.{$qtyTotal}/-</p>
            </div>
        </div>
    ";
}

echo "
    </div>
    <div class='order-summary'>
        <div class='order-summary-title'><p>Order summary</p></div>
        <div class='order-summary-content'>
            <p><span>Sub total:</span> <span>Rs.{$subtotal}</span></p>
            <p><span>Shipping charges:</span> <span>Rs.00</span></p>
            <p><span>Discount:</span> <span>Rs.00</span></p>
            <p><span>Add coupon code:</span> <span><input type='text' class='input-cupon' id='cupon'>
            <button class='input-cupon-btn'><img src='img/right-side-arrow-cupon.svg' alt=''></button></span></p>
        </div>
        <div class='order-samary-total'><p><span>Total:</span> <span>Rs.{$subtotal}</span></p></div>
        <button class='checkout-btn'>Checkout</button>
    </div>
</div>";



?>
