<?php
include('admin/db.php');

$data = json_decode(file_get_contents("php://input"), true);

session_start();



$product_id = $data['product_id'] ?? null;
$customer_id = $_SESSION['customer_id'];



if ($product_id) {
    $stmt = mysqli_query($conn, "DELETE FROM `cart` WHERE `Customer Id`= '$customer_id' AND `Product Id`='$product_id'");

    if ($stmt) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid input"]);
}
