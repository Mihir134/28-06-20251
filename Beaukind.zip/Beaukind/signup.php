<?php
include('admin/db.php');

$name = $_POST['name'];
$email = $_POST['email'];
$pass = password_hash($_POST['pass'], PASSWORD_BCRYPT);

// Check if user already exists
$check = mysqli_query($conn, "SELECT * FROM customer WHERE `Email Id` = '$email'");
if (mysqli_num_rows($check) > 0) {
    echo "Email already registered. Try logging in.";
    exit;
}

// Insert into database
$insert = mysqli_query($conn, "INSERT INTO customer (`First Name`, `Email Id`, `password`, `created_at`)
VALUES ('$name', '$email', '$pass', NOW())");

if ($insert) {
    echo "success";
} else {
    echo "Signup failed. Try again.";
}
