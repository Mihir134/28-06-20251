<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beaukind</title>

    <link rel="stylesheet" href="admin/css/bootstrap.css">




    <!-- favicon  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />


    <!-- css files  -->
    <link rel="stylesheet" href="css/landingpage.css">
    <link rel="stylesheet" href="css/navbar.css">



</head>

<body>
    <div class="widthcontent">
        
        <?php
            include "navbar.php";
        ?>


       
        



        <!-- Hero Section -->
        <header class="hero content-section" id="section1">
            <div class="hero-content">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                    when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                <a href="#" class="hero-btn">Explore More</a>
            </div>
        </header>

        <!-- about section  -->
        <section class="about-section content-section" id="section2">
            <div class="section-title-section">
                <h1>About Us</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                    industry's standard
                    dummy text ever since the 1500s</p>
            </div>

            <div class="about-description">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                    industry's standard
                    dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to
                    make
                    a type specimen
                    book. It has survived not only five centuries, but also the leap into electronic typesetting,
                    remaining
                    essentially
                    unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem
                    Ipsum
                    passages, and more
                    recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                </p>

                <div class="desc-container">
                    <div class="description-card">
                        <img src="img/tag1.svg" alt="">
                        <h2>Cruelty Free</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                    <div class="description-card">
                        <img src="img/tag2.svg" alt="">
                        <h2>Cruelty Free</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                    <div class="description-card">
                        <img src="img/tag3.svg" alt="">
                        <h2>Cruelty Free</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                    <div class="description-card">
                        <img src="img/tag4.svg" alt="">
                        <h2>Cruelty Free</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- product section  -->
        <section class="product-section content-section" id="section3">
            <div class="section-title-section">
                <h1>Products</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                    industry's
                    standard
                    dummy text ever since the 1500s</p>
            </div>

            <div class="product-container" id="product-container-homepage">
                <div class="product-card">
                    <img src="img/products (1).jpg" alt="">
                    <i>Product name</i>
                    <p>Description</p>
                    <button>
                        Add to cart
                    </button>
                </div>

            </div>
        </section>

        <!-- reviews -->

        <section class="reviews-section">
            <div class="section-title-section">
                <h1>Reviews</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                    industry's
                    standard
                    dummy text ever since the 1500s</p>
            </div>


            <div class="reviews-container">
                <swiper-container class="mySwiper" init="false" autoplay-delay="2500"
                    autoplay-disable-on-interaction="false">
                    <swiper-slide>
                        <div class="reviews-card">
                            <div class="reviews-part-one">
                                <img src="img/AlisaSharma.jpg" alt="">
                                <div class="reviews-customer-name">
                                    <p><i>Alisa Sharma</i></p>
                                    <p>Doctor</p>
                                </div>
                            </div>
                            <!-- <div class="reviews-part-two"> -->
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been
                                the industry's standard
                                dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                scrambled it
                                to make a type specimen
                                book. It has survived not only five centuries, but also the</p>
                            <!-- </div> -->
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <div class="reviews-card">
                            <div class="reviews-part-one">
                                <img src="img/AlisaSharma.jpg" alt="">
                                <div class="reviews-customer-name">
                                    <p><i>Alisa Sharma</i></p>
                                    <p>Doctor</p>
                                </div>
                            </div>
                            <!-- <div class="reviews-part-two"> -->
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been
                                the industry's standard
                                dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                scrambled it
                                to make a type specimen
                                book. It has survived not only five centuries, but also the</p>
                            <!-- </div> -->
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <div class="reviews-card">
                            <div class="reviews-part-one">
                                <img src="img/AlisaSharma.jpg" alt="">
                                <div class="reviews-customer-name">
                                    <p><i>Alisa Sharma</i></p>
                                    <p>Doctor</p>
                                </div>
                            </div>
                            <!-- <div class="reviews-part-two"> -->
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been
                                the industry's standard
                                dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                scrambled it
                                to make a type specimen
                                book. It has survived not only five centuries, but also the</p>
                            <!-- </div> -->
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <div class="reviews-card">
                            <div class="reviews-part-one">
                                <img src="img/AlisaSharma.jpg" alt="">
                                <div class="reviews-customer-name">
                                    <p><i>Alisa Sharma</i></p>
                                    <p>Doctor</p>
                                </div>
                            </div>
                            <!-- <div class="reviews-part-two"> -->
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been
                                the industry's standard
                                dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                scrambled it
                                to make a type specimen
                                book. It has survived not only five centuries, but also the</p>
                            <!-- </div> -->
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <div class="reviews-card">
                            <div class="reviews-part-one">
                                <img src="img/AlisaSharma.jpg" alt="">
                                <div class="reviews-customer-name">
                                    <p><i>Alisa Sharma</i></p>
                                    <p>Doctor</p>
                                </div>
                            </div>
                            <!-- <div class="reviews-part-two"> -->
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been
                                the industry's standard
                                dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                scrambled it
                                to make a type specimen
                                book. It has survived not only five centuries, but also the</p>
                            <!-- </div> -->
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <div class="reviews-card">
                            <div class="reviews-part-one">
                                <img src="img/AlisaSharma.jpg" alt="">
                                <div class="reviews-customer-name">
                                    <p><i>Alisa Sharma</i></p>
                                    <p>Doctor</p>
                                </div>
                            </div>
                            <!-- <div class="reviews-part-two"> -->
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been
                                the industry's standard
                                dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                scrambled it
                                to make a type specimen
                                book. It has survived not only five centuries, but also the</p>
                            <!-- </div> -->
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <div class="reviews-card">
                            <div class="reviews-part-one">
                                <img src="img/AlisaSharma.jpg" alt="">
                                <div class="reviews-customer-name">
                                    <p><i>Alisa Sharma</i></p>
                                    <p>Doctor</p>
                                </div>
                            </div>
                            <!-- <div class="reviews-part-two"> -->
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been
                                the industry's standard
                                dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                scrambled it
                                to make a type specimen
                                book. It has survived not only five centuries, but also the</p>
                            <!-- </div> -->
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <div class="reviews-card">
                            <div class="reviews-part-one">
                                <img src="img/AlisaSharma.jpg" alt="">
                                <div class="reviews-customer-name">
                                    <p><i>Alisa Sharma</i></p>
                                    <p>Doctor</p>
                                </div>
                            </div>
                            <!-- <div class="reviews-part-two"> -->
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been
                                the industry's standard
                                dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                scrambled it
                                to make a type specimen
                                book. It has survived not only five centuries, but also the</p>
                            <!-- </div> -->
                        </div>
                    </swiper-slide>
                    <swiper-slide>
                        <div class="reviews-card">
                            <div class="reviews-part-one">
                                <img src="img/AlisaSharma.jpg" alt="">
                                <div class="reviews-customer-name">
                                    <p><i>Alisa Sharma</i></p>
                                    <p>Doctor</p>
                                </div>
                            </div>
                            <!-- <div class="reviews-part-two"> -->
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been
                                the industry's standard
                                dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                scrambled it
                                to make a type specimen
                                book. It has survived not only five centuries, but also the</p>
                            <!-- </div> -->
                        </div>
                    </swiper-slide>
                </swiper-container>
            </div>


        </section>


        <section class="faqs-section">
            <div class="section-title-section">
                <h1>FAQs</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                    industry's
                    standard
                    dummy text ever since the 1500s</p>
            </div>

            <div class="faqs-container">
                <div class="accordion accordion-flush" id="accordionFlushExample">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseOne" aria-expanded="false"
                                aria-controls="flush-collapseOne">
                                Accordion Item #1
                            </button>
                        </h2>
                        <div id="flush-collapseOne" class="accordion-collapse collapse"
                            data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">Placeholder content for this accordion, which is intended to
                                demonstrate the <code>.accordion-flush</code> class. This is the first item’s accordion
                                body.</div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseTwo" aria-expanded="false"
                                aria-controls="flush-collapseTwo">
                                Accordion Item #2
                            </button>
                        </h2>
                        <div id="flush-collapseTwo" class="accordion-collapse collapse"
                            data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">Placeholder content for this accordion, which is intended to
                                demonstrate the <code>.accordion-flush</code> class. This is the second item’s accordion
                                body. Let’s imagine this being filled with some actual content.</div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseThree" aria-expanded="false"
                                aria-controls="flush-collapseThree">
                                Accordion Item #3
                            </button>
                        </h2>
                        <div id="flush-collapseThree" class="accordion-collapse collapse"
                            data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">Placeholder content for this accordion, which is intended to
                                demonstrate the <code>.accordion-flush</code> class. This is the third item’s accordion
                                body. Nothing more exciting happening here in terms of content, but just filling up the
                                space to make it look, at least at first glance, a bit more representative of how this
                                would look in a real-world application.</div>
                        </div>
                    </div>
                </div>
            </div>

        </section>

        <section class="findus-section content-section" id="section4">
            <div class="section-title-section">
                <h1>Find Us</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                    industry's
                    standard
                    dummy text ever since the 1500s</p>
            </div>


            <div class="findus-container">
                <div class="findus-part-one">
                    <div class="findus-card">
                        <p>
                            <img src="img/phone.svg" alt="">
                            4758392017
                        </p>
                    </div>
                    <div class="findus-card">
                        <p>
                            <img src="img/phone.svg" alt="">
                            4758392017
                        </p>
                    </div>
                    <div class="findus-card">
                        <p>
                            <img src="img/mail.svg" alt="">
                            abcdef@gmail.com
                        </p>
                    </div>
                    <div class="findus-card">
                        <p>
                            <img src="img/droplet.svg" alt="">
                            abcdef@gmail.com
                        </p>
                        <div>
                            <address>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has
                                been
                            </address>
                        </div>
                    </div>
                </div>
                <div class="findus-part-two">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d20765.84130634369!2d72.58458498246523!3d23.06351160659565!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e841a8fb6688b%3A0x74c28945e5a91979!2sCivil%20Hospital%2C%20Ahmedabad!5e0!3m2!1sen!2sin!4v1747492264329!5m2!1sen!2sin"
                        allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </section>

        <footer>
            <div class="footer-logo-content">
                <div class="footer-logo">
                    <img src="img/BeaukindLogo.svg" alt="">
                    <img src="img/BeaukindFootericon.svg" alt="">
                </div>
                <h1>“Redefining Luxury <br>In Beauty.”</h1>
            </div>
            <div class="footer-col">

                <h3><i>Main Links</i></h3>
                <p>Home</p>
                <p>About</p>
                <p>Beingkind</p>
                <p>Beaukind</p>
                <p>Products</p>

            </div>
            <div class="footer-col">

                <h3><i>Other Links</i></h3>
                <p>Privacy policy</p>
                <p>Terms & Co.</p>
                <p>Return policy</p>
                <p>Exchange policy</p>
                <p>Refund policy</p>

            </div>

            <div class="footer-contect">
                <h3><i>Subscribe our newsletter</i></h3>
                <form action="">
                    <input type="email" placeholder="Text here">
                    <button>Subscribe</button>
                </form>
                <h3><i>Social</i></h3>
                <div class="footer-social-media-links">
                    <img src="img/Social Icons.svg" alt="">
                    <img src="img/Social Icons (1).svg" alt="">
                    <img src="img/Social Icons (2).svg" alt="">
                    <img src="img/Social Icons (3).svg" alt="">
                </div>
            </div>
            <hr>
            <p>All Copyrights Reserved @ Beaukind 2025</p>


        </footer>


        <!-- swiper js -->
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>





        <script src="admin/js/bootstrap.js"></script>
        <script src="admin/js/popper.js"></script>
        <script src="admin/js/jquery.js"></script>
        <script src="js/logInsign.js"></script>
        <!-- <script src="admin/js/script.js"></script> -->



        <!-- linked scripts  -->
         <script src="js/cartproductcall.js"></script>
        <script src="js/ajexcall.js"></script>
        <script src="js/script.js"></script>
    </div>
</body>

</html>