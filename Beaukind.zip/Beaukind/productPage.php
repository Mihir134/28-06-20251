<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Beaukind</title>
    <link rel="stylesheet" href="admin/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />


    <link rel="stylesheet" href="css/landingpage.css" />
    <link rel="stylesheet" href="css/productpage.css" />
    <link rel="stylesheet" href="css/quentitymanagement.css">
    <link rel="stylesheet" href="css/navbar.css">

</head>

<body>
    <div class="widthcontent">
        

        <?php
            include "navbar.php";
        ?>

        

        <section class="" id="">

            <div class="product-details" id="productDetail" style="min-height: 80vh ; font-size:xx-large">
                Loading product details...
            </div>

            <div class="propage propage-two propage-prodetails">
                <h3>how it works:</h3>
                <div class="reviews-container">
                    <swiper-container class="mySwiper" init="false" autoplay-delay="2500"
                        autoplay-disable-on-interaction="false">
                        <swiper-slide>
                            <div class="how-it-work-card">

                                <img src="img/HowItWork (1).png" alt="">

                                <h3>Hyaluronic Acid</h3>


                                <p>Attracts and retains moisture, plumping the skin.
                                    Reduces fine lines and maintains a healthy moisture barrier, especially against sun
                                    damage.</p>

                            </div>
                        </swiper-slide>
                        <swiper-slide>
                            <div class="how-it-work-card">

                                <img src="img/HowItWork (2).png" alt="">

                                <h3>Ceramides & Vitamin C</h3>

                                <p>Ceramides restore the skin barrier, preventing moisture loss and reducing dryness
                                    caused by environmental stress.
                                    Vitamin C brightens skin, fights oxidative stress, and enhances sunscreen
                                    effectiveness by protecting against UV-induced damage.</p>

                            </div>
                        </swiper-slide>
                        <swiper-slide>
                            <div class="how-it-work-card">

                                <img src="img/HowItWork (3).png" alt="">

                                <h3>Glutathione & Citrullus Lanatus</h3>

                                <p>Glutathione works with Vitamin C to fade dark spots, improve radiance, and protect
                                    skin from UV damage.
                                    Citrullus Lanatus (Watermelon) soothes irritation, calms the skin, and provides
                                    protection against environmental damage.</p>

                            </div>
                        </swiper-slide>

                    </swiper-container>
                </div>
            </div>
            <!-- <hr> -->
            <div class="section-title-section">
                <h1>You may also like-</h1>
            </div>

            <div class="product-container" id="product-container-homepage">
                <div class="product-card">
                    <img src="img/products (1).jpg" alt="">
                    <i>Product name</i>
                    <p>Description</p>
                    <button>
                        <lord-icon src="https://cdn.lordicon.com/hcgabluf.json" trigger="morph" state="morph-fill"
                            style="width:30px;height:30px">
                        </lord-icon>
                        Add to cart
                    </button>
                </div>
                
            </div>
        </section>




        <footer>
            <div class="footer-logo-content">
                <div class="footer-logo">
                    <img src="img/BeaukindLogo.svg" alt="">
                    <img src="img/BeaukindFootericon.svg" alt="">
                </div>
                <h1>“Redefining LuxuryIn <br> Beauty.”</h1>
            </div>
            <div class="footer-col">

                <h3><i>Main Links</i></h3>
                <p>Home</p>
                <p>About</p>
                <p>Beingkind</p>
                <p>Beaukind</p>
                <p>Products</p>

            </div>
            <div class="footer-col">

                <h3><i>Other Links</i></h3>
                <p>Privacy policy</p>
                <p>Terms & Co.</p>
                <p>Return policy</p>
                <p>Exchange policy</p>
                <p>Refund policy</p>

            </div>

            <div class="footer-contect">
                <h3><i>Subscribe our newsletter</i></h3>
                <form action="">
                    <input type="email" placeholder="Text here">
                    <button>Subscribe</button>
                </form>
                <h3><i>Social</i></h3>
                <div class="footer-social-media-links">
                    <img src="img/Social Icons.svg" alt="">
                    <img src="img/Social Icons (1).svg" alt="">
                    <img src="img/Social Icons (2).svg" alt="">
                    <img src="img/Social Icons (3).svg" alt="">
                </div>
            </div>
        </footer>
    </div>
    <!-- swiper js -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>

    <script src="admin/js/bootstrap.js"></script>
    <script src="admin/js/popper.js"></script>
    <script src="admin/js/jquery.js"></script>
    
    <!-- linked scripts  -->
    <script src="js/ajexcallProductpage.js"></script>
    <script src="js/script.js"></script>   
    
    <script src="js/ajexcall.js"></script>

</body>

</html>