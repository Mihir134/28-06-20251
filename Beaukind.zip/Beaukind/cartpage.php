<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beaukind</title>
    <!-- bootstrap  -->
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">


    <!-- favicon  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />


    <!-- css files  -->
    <link rel="stylesheet" href="css/landingpage.css">
    <link rel="stylesheet" href="css/cartpage.css">
    <link rel="stylesheet" href="css/productpage.css">
    <link rel="stylesheet" href="css/navbar.css">
    <link rel="stylesheet" href="css/quentitymanagement.css">

</head>

<body>
    <div class="widthcontent">
        

        <?php
            include "navbar.php";
        ?>



        <section class="cart-section">
            <div class="section-title-subpage">
                <h1>Your Cart</h1>
            </div>

            <div id="carts-pros"> </div>

        </section>






        <footer>
            <div class="footer-logo-content">
                <div class="footer-logo">
                    <img src="img/BeaukindLogo.svg" alt="">
                    <img src="img/BeaukindFootericon.svg" alt="">
                </div>
                <h1>“Redefining Luxury <br>In Beauty.”</h1>
            </div>
            <div class="footer-col">

                <h3><i>Main Links</i></h3>
                <p>Home</p>
                <p>About</p>
                <p>Beingkind</p>
                <p>Beaukind</p>
                <p>Products</p>

            </div>
            <div class="footer-col">

                <h3><i>Other Links</i></h3>
                <p>Privacy policy</p>
                <p>Terms & Co.</p>
                <p>Return policy</p>
                <p>Exchange policy</p>
                <p>Refund policy</p>

            </div>

            <div class="footer-contect">
                <h3><i>Subscribe our newsletter</i></h3>
                <form action="">
                    <input type="email" placeholder="Text here">
                    <button>Subscribe</button>
                </form>
                <h3><i>Social</i></h3>
                <div class="footer-social-media-links">
                    <img src="img/Social Icons.svg" alt="">
                    <img src="img/Social Icons (1).svg" alt="">
                    <img src="img/Social Icons (2).svg" alt="">
                    <img src="img/Social Icons (3).svg" alt="">
                </div>
            </div>
            <hr>
            <p>All Copyrights Reserved @ Beaukind 2025</p>


        </footer>


        <!-- swiper js -->
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>



        <script src="admin/js/bootstrap.js"></script>
        <script src="admin/js/popper.js"></script>
        <script src="admin/js/jquery.js"></script>


        <!-- lordicon cdn   
        <script src="https://cdn.lordicon.com/lordicon.js"></script> -->


        <!-- linked scripts  -->
        <!-- <script src="js/script.js"></script> -->
        <!-- <script src="js/ajexcall.js"></script>         -->
        <script src="js/cartproductcall.js"></script>
        <!-- <script src="js/ajexcallProductpage.js"></script> -->
    </div>
</body>

</html>