<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "beaukind";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert product
$name = $_POST['name'];
$price = $_POST['price'];
$description = $_POST['description'];
$quantity = $_POST['quantity'];
$ingredients = $_POST['ingredients'];
$howToUse = $_POST['howToUse'];

$productStmt = $conn->prepare("INSERT INTO product (`Name`, `Price`, `Description`, `Quanity`, `Ingredients`, `How to use`) VALUES (?, ?, ?, ?, ?, ?)");
$productStmt->bind_param("sdssis", $name, $price, $description, $quantity, $ingredients, $howToUse);
$productStmt->execute();
$productId = $productStmt->insert_id;
$productStmt->close();

// Upload folder
$uploadDir = "uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Insert howitworks
foreach ($_FILES as $fileKey => $file) {
    if (strpos($fileKey, 'howWorkImg_') !== false && $file['error'] === 0) {
        $id = explode('_', $fileKey)[1];

        $title = $_POST["howWorkTitle_$id"];
        $desc  = $_POST["howWorkDesc_$id"];

        $imgName = time() . '_' . basename($file['name']);
        $targetPath = $uploadDir . $imgName;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            $howStmt = $conn->prepare("INSERT INTO howitworks (`How Work Img`, `How Work Title`, `How Work Desc`, `Product Id`) VALUES (?, ?, ?, ?)");
            $howStmt->bind_param("sssi", $targetPath, $title, $desc, $productId);
            $howStmt->execute();
            $howStmt->close();
        }
    }
}

$conn->close();

echo "✅ Product and How It Works data inserted successfully!";
