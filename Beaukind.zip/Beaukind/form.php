<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Product Form with Image Preview</title>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background: #f9f9f9;
        }

        form {
            background: white;
            padding: 25px;
            border-radius: 8px;
            max-width: 900px;
            margin: auto;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2,
        h3 {
            margin-top: 0;
        }

        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
        }

        input,
        textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        textarea {
            resize: vertical;
        }

        .dynamic-group {
            border: 1px solid #ddd;
            background: #fefefe;
            padding: 15px;
            margin-top: 20px;
            border-radius: 6px;
            position: relative;
        }

        .remove-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background: red;
            color: white;
            border: none;
            padding: 4px 8px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
        }

        .add-btn {
            margin-top: 20px;
            background: #007BFF;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .submit-btn {
            background: green;
            color: white;
            padding: 10px 20px;
            border: none;
            margin-top: 20px;
            border-radius: 5px;
            font-size: 15px;
            cursor: pointer;
        }

        .error {
            color: red;
            font-size: 13px;
        }

        .img-preview {
            margin-top: 10px;
            width: 72px;
            height: 72px;
            border: 1px solid #ccc;
            display: block;

        }

        @media (max-width: 600px) {
            form {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

    <form id="productForm" method="POST" action="insert.php" enctype="multipart/form-data">
        <h2>Product Information</h2>

        <label>Name</label>
        <input type="text" name="name" required>

        <label>Price</label>
        <input type="number" name="price" required>

        <label>Description</label>
        <textarea name="description" required></textarea>

        <label>Quantity</label>
        <input type="number" name="quantity" required>

        <label>Ingredients</label>
        <textarea name="ingredients" required></textarea>

        <label>How to Use</label>
        <textarea name="howToUse" required></textarea>

        <hr>
        <h3>How It Works</h3>

        <div id="howItWorksWrapper">
            <!-- Default 3 dynamic rows -->
        </div>

        <button type="button" class="add-btn" id="addMore">+ Add More</button>

        <br><br>
        <button type="submit" class="submit-btn">Submit</button>
    </form>

    <script>
        let howItWorkId = 1;

        function createHowItWorkRow(id) {
            return `
      <div class="dynamic-group" data-id="${id}">
        <button type="button" class="remove-btn" title="Remove">Remove</button>
        <label>HowItWork ID: ${id}</label>

        <label>How Work Img</label>
        <input type="file" name="howWorkImg_${id}" class="img-input" accept="image/*" required>
        <img src="img/Picture2.png" class="img-preview" id="preview_${id}">

        <label>How Work Title</label>
        <input type="text" name="howWorkTitle_${id}" required>

        <label>How Work Desc</label>
        <textarea name="howWorkDesc_${id}" required></textarea>

        <input type="hidden" name="productId_${id}" value="AUTO-FILL">
      </div>
    `;
        }

        // Initialize default 3 boxes
        $(document).ready(function() {
            for (let i = 0; i < 3; i++) {
                $('#howItWorksWrapper').append(createHowItWorkRow(howItWorkId++));
            }
        });

        // Add new row
        $('#addMore').on('click', function() {
            $('#howItWorksWrapper').append(createHowItWorkRow(howItWorkId++));
        });

        // Remove row
        $('#howItWorksWrapper').on('click', '.remove-btn', function() {
            $(this).closest('.dynamic-group').remove();
        });

        // Image preview handler
        $('#howItWorksWrapper').on('change', '.img-input', function() {
            const file = this.files[0];
            const previewId = $(this).siblings('.img-preview').attr('id');

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    $('#' + previewId).attr('src', e.target.result);
                }
                reader.readAsDataURL(file);
            }
        });

        // Form validation
        $('#productForm').on('submit', function(e) {
            e.preventDefault();
            let isValid = true;
            $('.error').remove();

            $(this).find('input[required], textarea[required]').each(function() {
                if (!$(this).val()) {
                    isValid = false;
                    $(this).after('<div class="error">This field is required</div>');
                }
            });

            if (isValid) {
                alert('Form submitted successfully!');
                // You can use FormData here to send images to a backend
            } else {
                alert('Please fill all required fields.');
            }
        });
    </script>

</body>

</html>