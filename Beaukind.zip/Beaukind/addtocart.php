<?php
// addtocart.php
session_start();
require_once 'admin/db.php';   // $conn  (mysqli)

header('Content-Type: text/plain');

if (!isset($_SESSION['customer_id'])) {
    echo 'login';   // front-end can redirect to login page
    exit;
}
$customerId = (int)$_SESSION['customer_id'];



// 2. Validate input
if (!isset($_POST['productId'], $_POST['qty'], $_POST['price'])) {
    http_response_code(400);
    echo 'Missing parameters';
    exit;
}

$productId = (int)$_POST['productId'];
$qty       = max(1, (int)$_POST['qty']);
$price     = (float)$_POST['price'];


// 3. Insert or update the cart row
$stmt = $conn->prepare(
    "SELECT `Cart Id`, Quentity 
     FROM cart 
     WHERE `Product Id` = ? AND `Customer Id` = ?"
);
$stmt->bind_param("ii", $productId, $customerId);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    // Already in cart – just bump quantity
    $newQty = $row['Quentity'] + $qty;
    $upd = $conn->prepare(
        "UPDATE cart SET Quentity = ?, Price = ? 
         WHERE `Cart Id` = ?"
    );
    $upd->bind_param("idi", $newQty, $price, $row['Cart Id']);
    $upd->execute();
} else {
    // Brand-new item
    $ins = $conn->prepare(
        "INSERT INTO cart (`Product Id`, `Customer Id`, Quentity, Price) 
         VALUES (?,?,?,?)"
    );
    $ins->bind_param("iiid", $productId, $customerId, $qty, $price);
    $ins->execute();
}


echo 'success';
