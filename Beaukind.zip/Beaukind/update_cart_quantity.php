<?php
include('admin/db.php');
session_start();
$data = json_decode(file_get_contents("php://input"), true);

$product_id = $data['product_id'] ?? null;
$quantity = $data['quantity'] ?? null;

$customer_id = $_SESSION['customer_id']; 

if ($product_id && $quantity) {
    $stmt = $conn->prepare("UPDATE cart SET Quentity = ? WHERE `Product Id` = ? AND `Customer Id` = ?");
    $stmt->bind_param("iii", $quantity, $product_id, $customer_id);
    
    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => $stmt->error]);
    }
    $stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid input"]);
}
?>
