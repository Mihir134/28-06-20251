<?php
session_start();
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;

$conn = new mysqli("localhost", "root", "", "your_database");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['email'])) {
        $email = $conn->real_escape_string($_POST['email']);
        $otp = rand(100000, 999999);
        $expires = date("Y-m-d H:i:s", strtotime("+10 minutes"));

        // Insert or update OTP
        $conn->query("INSERT INTO users (email, otp, otp_expires)
                      VALUES ('$email', '$otp', '$expires')
                      ON DUPLICATE KEY UPDATE otp='$otp', otp_expires='$expires'");

        // Send Email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = "smtp.gmail.com";
            $mail->SMTPAuth = true;
            $mail->Username = "your_email@gmail.com";       // your Gmail
            $mail->Password = "your_app_password";          // your App Password
            $mail->SMTPSecure = "tls";
            $mail->Port = 587;

            $mail->setFrom("your_email@gmail.com", "YourApp");
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = "Your OTP Code";
            $mail->Body = "Your login OTP is <strong>$otp</strong>. It expires in 10 minutes.";

            $mail->send();
            $_SESSION['email'] = $email;
            echo "OTP sent successfully to $email";
        } catch (Exception $e) {
            echo "Mailer Error: " . $mail->ErrorInfo;
        }
    } elseif (isset($_POST['otp'])) {
        $otp = $conn->real_escape_string($_POST['otp']);
        $email = $_SESSION['email'];

        $res = $conn->query("SELECT * FROM users WHERE email='$email' AND otp='$otp' AND otp_expires > NOW()");
        if ($res->num_rows === 1) {
            $_SESSION['loggedin'] = true;
            echo "Login successful!";
        } else {
            echo "Invalid or expired OTP.";
        }
    }
    exit;
}
?>

<!-- Simple Form UI -->
<!DOCTYPE html>
<html>

<head>
    <title>OTP Login</title>
</head>

<body>
    <?php if (!isset($_SESSION['email'])): ?>
        <form method="POST">
            <h3>Enter your Email</h3>
            <input type="email" name="email" required>
            <button type="submit">Send OTP</button>
        </form>
    <?php elseif (!isset($_SESSION['loggedin'])): ?>
        <form method="POST">
            <h3>Enter OTP sent to <?= $_SESSION['email'] ?></h3>
            <input type="text" name="otp" maxlength="6" required>
            <button type="submit">Verify OTP</button>
        </form>
    <?php else: ?>
        <h2>Welcome! You are logged in as <?= $_SESSION['email'] ?></h2>
    <?php endif; ?>
</body>

</html>