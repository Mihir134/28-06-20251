<?php
include('admin/db.php');
session_start();

$sql = mysqli_query($conn, "SELECT * FROM `product`");

// Set up default empty cart array
$cartProductIds = [];

if (isset($_SESSION['customer_id'])) {
    $customerid = $_SESSION['customer_id'];

    $checkcart = mysqli_query($conn, "SELECT `Product Id` FROM `cart` WHERE `Customer Id`='$customerid'");

    while ($cartItem = mysqli_fetch_assoc($checkcart)) {
        $cartProductIds[] = $cartItem['Product Id'];
    }
}

while ($row = mysqli_fetch_assoc($sql)) {
    echo "
        <div class='product-card'>
            <a href='productPage.php?Product={$row['Product Id']}'>
                <img src='admin/{$row['proimg1']}' alt=''>
            </a>
            <p class='Product-card-name'>{$row['Name']}</p>
            <p>{$row['Quanity']}</p>";

    // Check if current product is in cart
    if (in_array($row['Product Id'], $cartProductIds)) {
        echo "<button class='add-to-cart-btn' data-product-id='{$row['Product Id']}' data-price='{$row['Price']}' data-qty='1' data-status='added'>Added ✓</button>";
    } else {
        echo "<button class='add-to-cart-btn' data-product-id='{$row['Product Id']}' data-price='{$row['Price']}' data-qty='1' data-status='not-added'>Add to cart</button>";
    }

    echo "</div>";
}
