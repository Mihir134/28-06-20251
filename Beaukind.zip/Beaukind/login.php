<?php
include('admin/db.php');
session_start();

$email = $_POST['email'];
$password = $_POST['password'];

$result = mysqli_query($conn, "SELECT * FROM customer WHERE `Email Id` = '$email'");
if (mysqli_num_rows($result) === 1) {
    $user = mysqli_fetch_assoc($result);
    if (password_verify($password, $user['password'])) {
        $_SESSION['customer_id'] = $user['User Id'];
        echo $_SESSION['customer_id'];
        echo "success";
    } else {
        echo "Incorrect password.";
    }
} else {
    echo "User does not exist. Try signing up.";
}
