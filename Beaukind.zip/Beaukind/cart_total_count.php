<?php
include('admin/db.php');
session_start();

$customer_id = $_SESSION['customer_id'];

$sql = "SELECT COUNT(*) as total FROM cart WHERE `Customer Id` = '$customer_id'";
$result = mysqli_query($conn, $sql);
$data = mysqli_fetch_assoc($result);

echo json_encode(["cartTotalPro" => $data['total']]);
