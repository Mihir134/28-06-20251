<?php
include('db.php');

$proNm = $_POST['proNm'];
$proPrice = $_POST['proPrice'];
$proDesc = $_POST['proDesc'];
$proIngre = $_POST['proIngre'];
$proHowtouse = $_POST['proHowtouse'];
$proQty = $_POST['proQty'];

$targat1 = "image/ProductImges/" . basename($_FILES['proimg1']['name']);
move_uploaded_file($_FILES['proimg1']['tmp_name'], $targat1);

$targat2 = "image/ProductImges/" . basename($_FILES['proimg2']['name']);
move_uploaded_file($_FILES['proimg2']['tmp_name'], $targat2);

$targat3 = "image/ProductImges/" . basename($_FILES['proimg3']['name']);
move_uploaded_file($_FILES['proimg3']['tmp_name'], $targat3);

$targat4 = "image/ProductImges/" . basename($_FILES['proimg4']['name']);
move_uploaded_file($_FILES['proimg4']['tmp_name'], $targat4);

$targat5 = "image/ProductImges/" . basename($_FILES['proimg5']['name']);
move_uploaded_file($_FILES['proimg5']['tmp_name'], $targat5);



$sql = "INSERT INTO `product`(`Name`, `Price`, `Description`, `Quanity`, `Ingredients`, `How to use`, `proimg1`, `proimg2`, `proimg3`, `proimg4`, `proimg5`) VALUES ('$proNm','$proPrice','$proDesc','$proQty','$proIngre','$proHowtouse','$targat1','$targat2','$targat3','$targat4','$targat5')";

if ($conn->query($sql) == TRUE) {
    echo "Data inserted success fully";
} else {
    // echo "Unable to store data";
    echo error_reporting();
}
