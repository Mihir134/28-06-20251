<?php
require "db.php";
$adminemail = $_POST['adminemail'];
$adminpassword = $_POST['adminpassword'];

if ($adminemail == "" || $adminpassword == "") {
    echo json_encode([
        "status" => "error",
        "message" => "All fields are requeired."
    ]);
    die;
}

$varifyadmin = mysqli_query($conn, "SELECT * FROM `admin` WHERE `Email id`= '$adminemail' and `password` = '$adminpassword'");
$admindata = mysqli_fetch_array($varifyadmin);
if(mysqli_num_rows($varifyadmin) == 1){
    session_start();
    $_SESSION['admin_suc'] = $admindata;

    echo json_encode([
        "status" => "success",
        "message" => "Wellcome admin"
    ]);    
    
}else{
   echo json_encode([
        "status" => "error",
        "message" => "Invelid credentials"
    ]); 
}

// echo json_encode([
//         "status" => "error",
//         "message" => "Id is not defined. Unable to delete."
// ]);

// echo json_encode([
//     "status" => "success",
//     "message" => "Employee deleted successfully!"
// ]);
