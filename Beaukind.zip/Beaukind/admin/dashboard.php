<?php
// dashboard.php (updated with category links)
include "db.php";
session_start();
if (!isset($_SESSION['admin_suc'])) header("Location: adm_login.php");
$page = $_GET['page'] ?? 'blog_table';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/admin_sidebar.css">
</head>

<body>
  <div class="sidebar">
    <div class="BeaukindLogo">
      <img src="image/beauking_logo.svg" alt="">
    </div>
    <a href="?page=adm_product" class="d-flex align-items-center gap-1 <?= $page == 'adm_product' ? 'active' : '' ?>">Product
      
    </a>
    <a href="?page=category_table" class="d-flex align-items-center gap-1 <?= $page == 'category_table' ? 'active' : '' ?>">Manage Categories
      
    </a>
    <a href="?page=author_table" class="d-flex align-items-center gap-1 <?= $page == 'author_table' ? 'active' : '' ?>">Manage authors
      
    </a>
    <a href="logout.php" class="btn btn-danger w-100 mt-4 d-flex align-items-center justify-content-center gap-1"> <b>Logout</b>
      
    </a>
  </div>

  <div class="content">
    <h3 class="mb-4 d-flex align-items-center">Dashboard</h3>
    <?php
    switch ($page) {
      case 'adm_product':
        include "adm_product.php";
        break;
      case 'dashboardHome':
        include "dashboardHome.php";
        break;
      case 'category_form':
        include "category_form.php";
        break;
      case 'category_table':
        include "category_table.php";
        break;
      case 'author_form':
        include "author_form.php";
        break;
      case 'author_table':
        include "author_table.php";
        break;
      default:
        include "dash_default.php";
        break;
    }
    ?>
  </div>
  <script src="./ckeditor/ckeditor/ckeditor.js"></script>
  <script src="https://cdn.lordicon.com/lordicon.js"></script>
</body>

</html>