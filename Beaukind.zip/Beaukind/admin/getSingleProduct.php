<?php
include 'db.php';
session_start();

header('Content-Type: text/html; charset=utf-8');

$customer_id = $_SESSION['customer_id'] ?? null;
$cartProductIds = [];

// Fetch product IDs in user's cart
if ($customer_id) {
    $checkcart = mysqli_query($conn, "SELECT `Product Id`, `Quentity` FROM `cart` WHERE `Customer Id` = '$customer_id'");
    while ($cartItem = mysqli_fetch_assoc($checkcart)) {
        $cartProductIds[$cartItem['Product Id']] = $cartItem['Quentity'];
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    // $qty = 1; // Default quantity shown on the product page
    $qty = isset($cartProductIds[$id]) ? (int)$cartProductIds[$id] : 1;



    // Get product data
    $sql = "SELECT * FROM product WHERE `Product Id` = '$id'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) === 1) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "
            <div class='propage'>
                <div class='propage-part-one'>
                    <div class='propage-img-container'>
                        <div class='main-image' id='mainImageContainer'>
                            <img id='mainImage' src='admin/{$row['proimg1']}' alt='Main'>
                            <img id='zoomLens' class='zoom-lens' src='admin/{$row['proimg1']}' alt='Zoom'>
                        </div>
                        <div class='thumbnails'>
                            <img src='admin/{$row['proimg2']}' data-full='admin/{$row['proimg2']}' data-zoom='admin/{$row['proimg2']}' class='active'>
                            <img src='admin/{$row['proimg3']}' data-full='admin/{$row['proimg3']}' data-zoom='admin/{$row['proimg3']}'>
                            <img src='admin/{$row['proimg4']}' data-full='admin/{$row['proimg4']}' data-zoom='admin/{$row['proimg4']}' class='active'>
                            <img src='admin/{$row['proimg5']}' data-full='admin/{$row['proimg5']}' data-zoom='admin/{$row['proimg5']}'>
                            <img src='admin/{$row['proimg1']}' data-full='admin/{$row['proimg1']}' data-zoom='admin/{$row['proimg1']}' class='active'>
                        </div>
                    </div>
                </div>
                <div class='propage-part-two'>
                    <div class='propage-prodetails'>
                        <div class='propage-flex-incard'>
                            <h1>{$row['Name']}</h1>
                            <h3>₹{$row['Price']}</h3>
                        </div>
                        <div class='stars'>
                            <img src='img/star.svg' alt=''>
                            <img src='img/star.svg' alt=''>
                            <img src='img/star.svg' alt=''>
                            <img src='img/star.svg' alt=''>
                            <img src='img/star.svg' alt=''>
                            (60)
                        </div>
                    </div>
                    <div class='propage-prodetails'>
                        <h3>Description</h3>
                        <p>{$row['Description']}</p>
                    </div>
                    <div class='propage-prodetails'>
                        <h3>Quantity</h3>
                        <p>{$row['Quanity']}</p>

                        <form class='product-quentity'>
                            <div class='propage-pro-quentity'>
                                <button type='button' class='propage-qty-btn' onclick='decrease(this)'>
                                    <img src='img/square-subtract.svg' alt='Decrease'>
                                </button>

                                <input type='number' name='qty' class='cart-pro-qty-btn' value='{$qty}' readonly min='1' max='10'>

                                <button type='button' class='propage-qty-btn' onclick='increase(this)'>
                                    <img src='img/square-plus.svg' alt='Increase'>
                                </button>
                            </div>";

            $status = in_array($row['Product Id'], $cartProductIds) ? 'added' : 'not-added';
            $btnText = $status === 'added' ? 'Added ✓' : 'Add to cart';

            echo "
                <button class='add-to-cart-btn' 
                        data-product-id='{$row['Product Id']}' 
                        data-price='{$row['Price']}' 
                        data-qty='{$qty}' 
                        data-status='{$status}'>{$btnText}</button>
                </form>
            </div>
            <div class='propage-prodetails'>
                <h3>Free shipping above Rs. 200/-</h3>
                <h3>Dispatched within 4-5 days</h3>
            </div>
        </div>
    </div>

    <div class='propage propage-two'>
        <div class='propage-prodetails'>
            <h3>Ingredients:</h3>
            <p>{$row['Ingredients']}</p>
        </div>
        <div class='propage-prodetails'>
            <h3>How to use:</h3>
            <p>{$row['How to use']}</p>
        </div>
    </div>";
        }
    } else {
        echo "<p class='error'>Product not found.</p>";
    }
} else {
    echo "<p class='error'>Invalid request method.</p>";
}
