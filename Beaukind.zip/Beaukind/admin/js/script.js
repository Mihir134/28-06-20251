// product page form validation

$(document).ready(function () {
    // Real-time validation
    function validateTextInput(id) {
        const input = $(id);
        if (input.val().trim() === "") {
            input.addClass("is-invalid");
            return false;
        } else {
            input.removeClass("is-invalid").addClass("is-valid");
            return true;
        }
    }

    function validateTextarea(id) {
        const input = $(id);
        if (input.val().trim() === "") {
            input.addClass("is-invalid");
            return false;
        } else {
            input.removeClass("is-invalid").addClass("is-valid");
            return true;
        }
    }

    function validateImageInput(id) {
        const input = $(id)[0];
        const file = input.files[0];
        const allowedTypes = ["image/jpeg", "image/png", "image/jpg", "image/gif", "image/webp"];
        if (file && allowedTypes.includes(file.type)) {
            $(id).removeClass("is-invalid").addClass("is-valid");
            return true;
        } else {
            $(id).addClass("is-invalid");
            return false;
        }
    }

    // Attach events
    $("#proNm, #proPrice, #proQty").on("keyup blur", function () {
        validateTextInput(`#${this.id}`);
    });

    $("#proDesc, #proIngre, #proHowtouse").on("keyup blur", function () {
        validateTextarea(`#${this.id}`);
    });

    $("#proimg1, #proimg2, #proimg3, #proimg4, #proimg5").on("change", function () {
        validateImageInput(`#${this.id}`);
    });



    // inset into product table 

    // Final form submission
    $("form").on("submit", function (e) {
        e.preventDefault(); // prevent form submission

        const isValid =
            validateTextInput("#proNm") &
            validateTextInput("#proPrice") &
            validateTextarea("#proDesc") &
            validateTextarea("#proIngre") &
            validateTextarea("#proHowtouse") &
            validateTextInput("#proQty") &
            validateImageInput("#proimg1") &
            validateImageInput("#proimg2") &
            validateImageInput("#proimg3") &
            validateImageInput("#proimg4") &
            validateImageInput("#proimg5");

        if (isValid) {
            function addProduct() {
                let formData = new FormData();

                formData.append("proNm", $("#proNm").val());
                formData.append("proPrice", $("#proPrice").val());
                formData.append("proDesc", $("#proDesc").val());
                formData.append("proIngre", $("#proIngre").val());
                formData.append("proHowtouse", $("#proHowtouse").val());
                formData.append("proQty", $("#proQty").val());
                formData.append("proimg1", $("#proimg1")[0].files[0]);
                formData.append("proimg2", $("#proimg2")[0].files[0]);
                formData.append("proimg3", $("#proimg3")[0].files[0]);
                formData.append("proimg4", $("#proimg4")[0].files[0]);
                formData.append("proimg5", $("#proimg5")[0].files[0]);

                console.log(formData);

                $.ajax({
                    url: "Prodduct_insert.php",
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        console.log(data);
                        alert(data);

                        $("#productForm")[0].reset();
                    },
                    error: function (err) {
                        console.error(err);
                        alert("Error uploading data.");
                    }
                });
            }

            // alert("i am called");
            addProduct();
            // alert("i am done calling");

        } else {
            alert("Please correct the errors before submitting.");
        }
    });


    // retrive data from product table

    function showProductData() {
        output = "";
        productcard = "";
        $.ajax({
            url: "product_Retrieve.php",
            method: "GET",
            dataType: "json",
            success: function (data) {
                console.log(data);
                data.forEach(data => {
                    output += `
                        <tr>
                            <td data-col="col-1">${data["Product Id"]}</td>
                            <td data-col="col-2">${data.Name}</td>
                            <td data-col="col-3">${data.Price}</td>
                            <td data-col="col-4">${data.Quanity}</td>
                            <td data-col="col-5">${data.Description}</td>
                            <td data-col="col-6">${data["How to use"]}</td>
                            <td data-col="col-7">${data.Ingredients}</td>
                            <td data-col="col-8"> <img src="${data.proimg1}" alt="img1" width="50"></td>
                            <td data-col="col-9"> <img src="${data.proimg2}" alt="img2" width="50"></td>
                            <td data-col="col-10"> <img src="${data.proimg3}" alt="img3" width="50"></td>
                            <td data-col="col-11"> <img src="${data.proimg4}" alt="img4" width="50"></td>
                            <td data-col="col-12"> <img src="${data.proimg5}" alt="img5" width="50"></td>
                            <td> <button>Edit</button> <button>Delete</button> </td>
                        </tr>
                    `; 

                 
                    
                    

                });

                // console.log(productcard);
                $("#product-table").html(output);
            

            },
        });
    }
    showProductData();

});
