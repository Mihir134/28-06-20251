<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Login</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <style>
        body,
        html {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #d9d6cb;
        }

        .container {
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 220px;
            background-color: #cfcfc8;
            padding: 20px;
            box-sizing: border-box;
        }

        

        .nav {
            font-size: 16px;
            color: #333;
        }

        .main-content {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-modal {
            background-color: #f8f5ed;
            padding: 32px;
            width: 360px;
            box-shadow: 0 0 12px rgba(0, 0, 0, 0.15);
            border-radius: 6px;
            position: relative;
        }

        .login-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .login-header h2 {
            margin: 0;
            font-size: 20px;
            color: #333;
        }

        .close {
            cursor: pointer;
            font-size: 22px;
            color: #666;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin: 12px 0 4px;
            font-size: 14px;
            color: #333;
        }

        input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .forgot {
            font-size: 12px;
            margin-top: 6px;
            margin-bottom: 14px;
            color: #555;
            text-decoration: none;
            align-self: flex-end;
        }

        .continue {
            background-color: #1c2d2f;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 4px;
            margin-bottom: 12px;
            cursor: pointer;
            font-weight: bold;
        }

        .google-login {
            background-color: transparent;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 4px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            cursor: pointer;
        }

        .google-login img {
            width: 16px;
            height: 16px;
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Toast Container -->
        <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 9999">
            <div id="liveToast" class="toast align-items-center border-0" role="alert" aria-live="assertive"
                aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body" id="toastMsg">
                        <!-- Message will appear here -->
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                        aria-label="Close"></button>
                </div>
            </div>
        </div>


        <aside class="sidebar">
            <div class="BeaukindLogo ">
                <img src="image/BeaukindLogo.svg" alt="" class="visuallogobeaukind">
                <img src="image/Beaukind.png" alt="" class="textlogobeaukind">
            </div>
            <div class="nav">Dashboard</div>
        </aside>

        <main class="main-content">
            <div class="login-modal">
                <div class="login-header">
                    <h2>Admin Login</h2>
                    <span class="close">&times;</span>
                </div>
                <form id="adminlogin">
                    <label for="email">Mail Id</label>
                    <input type="email" id="adminemail" placeholder="Admin@gmail.com" />

                    <label for="password">Password</label>
                    <input type="password" id="adminpassword" placeholder="••••••" />

                    <a href="#" class="forgot">Forgot password?</a>

                    <button type="submit" class="continue">Continue</button>
                    <button type="button" class="google-login">
                        <img src="https://www.google.com/favicon.ico" alt="G"> Login with Google
                    </button>
                </form>

            </div>
        </main>
    </div>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/popper.js"></script>

    <script>
        // document.querySelector(".close").addEventListener("click", () => {
        //     document.querySelector(".login-modal").style.display = "none";
        // });
        $(document).ready(function() {
            $("#adminlogin").on("submit", function(e) {
                // alert("button is clickd");
                e.preventDefault();
                let adminemail = $("#adminemail").val().trim();
                let adminpassword = $("#adminpassword").val().trim();

                let formData = new FormData();
                formData.append("adminemail", adminemail);
                formData.append("adminpassword", adminpassword);

                $.ajax({
                    type: "POST",
                    url: "admin_login_process.php",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        const res = typeof response === "string" ? JSON.parse(response) : response;

                        $("#toastMsg").text(res.message);

                        const toastElement = document.getElementById("liveToast");
                        toastElement.classList.remove("text-bg-success", "text-bg-danger", "text-bg-primary");

                        if (res.status === "success") {
                            toastElement.classList.add("text-bg-success");
                            document.getElementById("adminlogin").reset(); // ✅ Correct reset
                            window.location.href = "dashboard.php";
                        } else {
                            toastElement.classList.add("text-bg-danger");
                        }

                        const toast = new bootstrap.Toast(toastElement);
                        toast.show();
                    }

                });
            });

        });
    </script>



</body>

</html>