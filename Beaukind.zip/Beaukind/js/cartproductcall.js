$(document).ready(function () {
    function loadCartProducts() {
        $.ajax({
            url: "retrive_cart_pro.php",
            method: "GET",
            dataType: "html",
            success: function (data) {
                $("#carts-pros").html(data);
                // console.log(data.cartTotalPro);
            },
            error: function (xhr, status, error) {
                console.error("Error loading cart:", error);
            }
        });
    }

    // Call once on page load
    loadCartProducts();


    function updateCartQtyUI() {
        $.ajax({
            url: "cart_total_count.php",
            method: "GET",
            dataType: "json",
            success: function (data) {
                if (data.cartTotalPro !== undefined) {
                    $("#cart-nav-qty").text(data.cartTotalPro);
                    // console.log(data.cartTotalPro)
                }
            },
            error: function (xhr, status, error) {
                console.error("Error fetching cart total:", error);
            }
        });
    }
    updateCartQtyUI();
    // Make these global so inline onclicks work
    window.increase = function (productId, price) {
        const qtyInput = document.getElementById(`qty-${productId}`);
        if (!qtyInput) return;

        let qty = parseInt(qtyInput.value);
        if (qty < 10) {
            qty++;
            qtyInput.value = qty;
            updateQuantityInDB(productId, qty);
            // Optional: reload cart for updated totals
            loadCartProducts();

        }
    };

    window.decrease = function (productId, price) {
        const qtyInput = document.getElementById(`qty-${productId}`);
        if (!qtyInput) return;

        let qty = parseInt(qtyInput.value);
        if (qty > 1) {
            qty--;
            qtyInput.value = qty;
            updateQuantityInDB(productId, qty);
            // Optional: reload cart for updated totals
            loadCartProducts();

        }
    };

    window.RemoveFromCart = function (productId) {

        fetch("DeleteFromCart.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                product_id: productId,
            })
        })
            .then(res => res.json())
            .then(data => {
                if (data.status === "success") {
                    loadCartProducts(); // Refresh cart
                    updateCartQtyUI();
                    showProductData();

                } else {
                    console.error("Failed to delete:", data.message);
                }
            })
            .catch(err => {
                console.error("Error Delete update:", err);
            });
    }

    function updateQuantityInDB(productId, qty) {
        fetch("update_cart_quantity.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                product_id: productId,
                quantity: qty
            })
        })
            .then(res => res.json())
            .then(data => {
                if (data.status !== "success") {
                    console.error("Failed to update quantity:", data.message);
                }
            })
            .catch(err => {
                console.error("Error sending update:", err);
            });
    }
});
