
const buttons = document.querySelectorAll(".accordion-button");

buttons.forEach((button) => {
    button.addEventListener("click", () => {
        const parent = button.closest(".accordion-item");
        const content = parent.querySelector(".accordion-collapse");
        const isActive = content.classList.contains("show");

        // Close all
        document.querySelectorAll(".accordion-collapse").forEach(c => c.classList.remove("show"));
        document.querySelectorAll(".accordion-button").forEach(b => b.classList.remove("active"));

        // Toggle current
        if (!isActive) {
            content.classList.add("show");
            button.classList.add("active");
        }
    });
});


//navbar links
const sections = document.querySelectorAll('.content-section');
const navLinks = document.querySelectorAll('.nav-link');

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const id = entry.target.id;
            navLinks.forEach(link => {
                link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
            });
        }
    });
}, {
    threshold: 0.6
});

sections.forEach(section => observer.observe(section));



// quentity management




function increase(btn) {
    const container = btn.closest('.propage-pro-quentity');
    const input = container.querySelector('input[type="number"]');
    const current = parseInt(input.value);
    if (current < 10) {
        input.value = current + 1;
    }
}

function decrease(btn) {
    const container = btn.closest('.propage-pro-quentity');
    const input = container.querySelector('input[type="number"]');
    const current = parseInt(input.value);
    if (current > 1) {
        input.value = current - 1;
    }
}


// reviews

const swiperEl = document.querySelector('swiper-container')
Object.assign(swiperEl, {
    slidesPerView: 1,
    spaceBetween: 10,
    pagination: {
        clickable: true,
    },
    breakpoints: {
        640: {
            slidesPerView: 1,
            spaceBetween: 20,
        },
        768: {
            slidesPerView: 2,
            spaceBetween: 40,
        },
        1024: {
            slidesPerView: 3,
            spaceBetween: 50,
        },
    },
});
swiperEl.initialize();




// product image scroll

function initializeZoomFeature() {
    const mainImage = document.getElementById("mainImage");
    const zoomLens = document.getElementById("zoomLens");
    const maincontainer = document.getElementById("mainImageContainer");
    const thumbnails = document.querySelectorAll(".thumbnails img");

    if (!mainImage || !zoomLens || !maincontainer) return;

    maincontainer.addEventListener("mousemove", (e) => {
        const rect = maincontainer.getBoundingClientRect(); // FIX: was 'container'
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        zoomLens.style.left = -x + "px";
        zoomLens.style.top = -y + "px";
    });

    maincontainer.addEventListener("mouseenter", () => {
        zoomLens.style.display = "block";
    });

    maincontainer.addEventListener("mouseleave", () => {
        zoomLens.style.display = "none";
    });

    thumbnails.forEach(thumb => {
        thumb.addEventListener("click", () => {
            thumbnails.forEach(t => t.classList.remove("active"));
            thumb.classList.add("active");
            mainImage.src = thumb.getAttribute("data-full");
            zoomLens.src = thumb.getAttribute("data-zoom");
        });
    });
}
  