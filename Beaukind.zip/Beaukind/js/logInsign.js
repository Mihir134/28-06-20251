$(document).ready(function () {
    // SIGNUP
    $('#signupBtn').click(function () {
        alert("signup clicked");
        let name = $('#signupName').val().trim();
        let email = $('#signupEmail').val().trim();
        let pass = $('#signupPassword').val();
        let cpass = $('#signupCPass').val();

        if (!name || !email || !pass || !cpass) {
            alert("All fields are required.");
            return;
        }

        if (pass !== cpass) {
            alert("Passwords do not match.");
            return;
        }

        $.ajax({
            url: 'signup.php',
            type: 'POST',
            data: {
                name: name,
                email: email,
                pass: pass
            },
            success: function (res) {
                if (res.trim() === 'success') {
                    alert("Signup successful! Now login to start shopping your favorite things.");
                    let loginModal = new bootstrap.Modal(document.getElementById('exampleModalToggle'));
                    loginModal.show();
                    bootstrap.Modal.getInstance(document.getElementById('exampleModalToggle2')).hide();
                } else {
                    alert(res);
                }
            },
            error: function () {
                alert("Error contacting server.");
            }
        });
    });

    // LOGIN
    $('#loginBtn').click(function () {
        alert("log in cliked ");
        let email = $('#emailLogin').val().trim();
        let password = $('#PasswordLogin').val();

        if (!email || !password) {
            alert("Please fill in both fields.");
            return;
        }

        $.ajax({
            url: 'login.php',
            type: 'POST',
            data: {
                email: email,
                password: password
            },
            success: function (res) {
                if (res.trim() === 'success') {
                    alert("Now you can start shopping your favorite things!");
                    location.reload(); // or redirect to another page
                } else {
                    alert(res);
                }
            },
            error: function () {
                alert("Error contacting server.");
            }
        });
    });
});
