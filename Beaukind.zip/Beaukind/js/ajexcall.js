$(document).ready(function () {
    function showProductData() {
        $.ajax({
            url: "showproduct.php",
            method: "GET",
            dataType: "html",
            success: function (data) {
                $("#product-container-homepage").html(data);
            },
        });
    }

    showProductData();
    function updateCartQtyUI() {
        $.ajax({
            url: "cart_total_count.php",
            method: "GET",
            dataType: "json",
            success: function (data) {
                if (data.cartTotalPro !== undefined) {
                    $("#cart-nav-qty").text(data.cartTotalPro);
                    // console.log(data.cartTotalPro)
                }
            },
            error: function (xhr, status, error) {
                console.error("Error fetching cart total:", error);
            }
        });
    }
    updateCartQtyUI();





    function bindAddToCartHandler(containerSelector) {
        $(containerSelector).on("click", ".add-to-cart-btn", function (e) {
            e.preventDefault();

            const $btn = $(this);
            const productId = $btn.data("product-id");
            const price = $btn.data("price");
            const qty = $btn.data("qty") || 1;
            const currentStatus = $btn.data("status");

            if (currentStatus === "added") {
                fetch("DeleteFromCart.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ product_id: productId })
                })
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === "success") {
                            $btn
                                .text("Add to cart")
                                .data("status", "not-added")
                                .removeAttr("disabled");
                            updateCartQtyUI();
                        } else {
                            alert("Error removing from cart");
                        }
                    });
            } else {
                $.ajax({
                    url: "addtocart.php",
                    method: "POST",
                    data: { productId, price, qty },
                    dataType: "text",
                    success: function (resp) {
                        if (resp.trim() === "success") {
                            $btn
                                .text("Added ✓")
                                .data("status", "added")
                                .attr("disabled", false);
                            updateCartQtyUI();
                        } else if (resp.trim() === "login") {
                            window.location.href = "login.html";
                        } else {
                            alert(resp);
                        }
                    },
                    error: function () {
                        alert("Server error – please try again.");
                    }
                });
            }
        });
    }

    $(document).ready(function () {
        function showProductData() {
            $.ajax({
                url: "showproduct.php",
                method: "GET",
                dataType: "html",
                success: function (data) {
                    $("#product-container-homepage").html(data);
                },
            });
        }

        function updateCartQtyUI() {
            $.ajax({
                url: "cart_total_count.php",
                method: "GET",
                dataType: "json",
                success: function (data) {
                    if (data.cartTotalPro !== undefined) {
                        $("#cart-nav-qty").text(data.cartTotalPro);
                        // console.log(data.cartTotalPro);
                    }
                },
                error: function (xhr, status, error) {
                    console.error("Error fetching cart total:", error);
                }
            });
        }

        // Initial calls
        showProductData();
        updateCartQtyUI();

        // Bind events on both homepage and product detail views
        bindAddToCartHandler("#product-container-homepage");
        bindAddToCartHandler("#productDetail"); // ✅ This is the missing part
    });
    


//     $("#product-container-homepage").on("click", ".add-to-cart-btn", function (e) {
//         e.preventDefault();

//         const $btn = $(this);
//         const productId = $btn.data("product-id");
//         const price = $btn.data("price");
//         const qty = $btn.data("qty") || 1;
//         const currentStatus = $btn.data("status");

//         if (currentStatus === "added") {
//             // Remove from cart
//             fetch("DeleteFromCart.php", {
//                 method: "POST",
//                 headers: { "Content-Type": "application/json" },
//                 body: JSON.stringify({ product_id: productId })
//             })
//                 .then(res => res.json())
//                 .then(data => {
//                     if (data.status === "success") {
//                         $btn
//                             .text("Add to cart")
//                             .data("status", "not-added")
//                             .removeAttr("disabled");
//                         updateCartQtyUI();

//                     } else {
//                         alert("Error removing from cart");
//                     }
//                 });
//         } else {
//             // Add to cart
//             $.ajax({
//                 url: "addtocart.php",
//                 method: "POST",
//                 data: { productId, price, qty },
//                 dataType: "text",
//                 success: function (resp) {
//                     if (resp.trim() === "success") {
//                         $btn
//                             .text("Added ✓")
//                             .data("status", "added")
//                             .attr("disabled", false); // Remove this if you want toggle to work
//                         updateCartQtyUI();

//                     } else if (resp.trim() === "login") {
//                         window.location.href = "login.html";
//                     } else {
//                         alert(resp);
//                     }
//                 },
//                 error: function () {
//                     alert("Server error – please try again.");
//                 }
//             });
//         }
//     });

});
