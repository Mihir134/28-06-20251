function getProductIdFromURL() {
    const params = new URLSearchParams(window.location.search);
    return params.get("Product");
}

const productId = getProductIdFromURL();

if (productId) {
    $.ajax({
        url: "admin/getSingleProduct.php",
        method: "POST",
        data: { id: productId },
        dataType: "html",
        success: function (product) {
            
            

                $("#productDetail").html(product);
                initializeZoomFeature();
            
            
            
        },
        error: function (err) {
            console.error(err);
            $("#productDetail").html("Error loading product.");
        }
    });
} else {
    $("#productDetail").html("No product ID found in URL.");
}

