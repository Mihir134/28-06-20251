<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AJAX Blog Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .card-img-top { height: 200px; object-fit: cover; }
  </style>
</head>
<body class="bg-light">
  <div class="container py-5">
    <h1 class="text-center mb-4">Latest Blog Posts</h1>
    <div id="blog-container" class="row"></div>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(document).ready(function() {
      $.ajax({
        url: 'fetch_blog_data.php',
        method: 'GET',
        dataType: 'json',
        success: function(posts) {
          if (posts.length > 0) {
            posts.forEach(function(post) {
              $('#blog-container').append(`
                <div class="col-md-4 mb-4">
                  <div class="card h-100 shadow-sm">
                    <img src="${post.Img}" class="card-img-top" alt="${post.post_title}">
                    <div class="card-body">
                      <h5 class="card-title">${post.post_title}</h5>
                      <p class="card-text small text-muted">By ${post.author} | ${post.category}</p>
                      <p class="card-text">${post.pagecontent.substring(0, 100)}...</p>
                      <a href="post.php?slug=${post.page_slug}" class="btn btn-primary btn-sm">Read More</a>
                    </div>
                  </div>
                </div>
              `);
            });
          } else {
            $('#blog-container').html('<p class="text-center text-danger">No blog posts found.</p>');
          }
        },
        error: function() {
          $('#blog-container').html('<p class="text-center text-danger">Failed to load blog posts.</p>');
        }
      });
    });
  </script>
</body>
</html>
