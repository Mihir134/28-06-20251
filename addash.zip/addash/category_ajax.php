<?php
include "db.php";
$action = $_REQUEST['action'] ?? '';

if ($action === "save") {
  $id = $_POST['id'];
  $name = $_POST['categoryName'];
  $status = $_POST['status'];

  if ($id) {
    $conn->query("UPDATE category SET categoryName='$name', status='$status' WHERE id=$id");
  } else {
    $conn->query("INSERT INTO category (categoryName, status) VALUES ('$name', '$status')");
  }
  exit;
}

if ($action === "read") {
  $res = $conn->query("SELECT * FROM `category`");
  echo "<table class='table table-bordered text-center'><tr><th>ID</th><th>Name</th><th>Status</th><th>Created At</th><th>Actions</th></tr>";
  while ($row = $res->fetch_assoc()) {
    echo "<tr>
      <td>{$row['id']}</td>
      <td>{$row['categoryName']}</td>
      ";
      if($row['status']=="Active"){
        echo "<td style='color:green;'>{$row['status']}</td>";
      }else{
        echo "<td style='color:red;'>{$row['status']}</td>";
      }
      echo "
      <td>{$row['created_at']}</td>
      <td>
        <button class='btn btn-warning btn-sm' onclick='editCategory({$row['id']})'>
          <lord-icon src='https://cdn.lordicon.com/cfkiwvcc.json' trigger='hover' style='width:25px;height:25px'></lord-icon>
        </button>
        <button class='btn btn-danger btn-sm' onclick='deleteCategory({$row['id']})'>
          <lord-icon src='https://cdn.lordicon.com/oqeixref.json' trigger='morph' state='morph-trash-full' style='width:25px;height:25px'></lord-icon>
        </button>
      </td>
    </tr>";
  }
  echo "</table>";
  exit;
}

if ($action === "get") {
  $id = $_GET['id'];
  $res = $conn->query("SELECT * FROM category WHERE id=$id");
  echo json_encode($res->fetch_assoc());
  exit;
}

if ($action === "delete") {
  $id = $_POST['id'];
  $conn->query("DELETE FROM category WHERE id=$id");
  exit;
}
?>
