<?php
// dashboard.php (updated with category links)
include "db.php";
if (!isset($_SESSION['user_id'])) header("Location: index.html");
$page = $_GET['page'] ?? 'blog_table';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      overflow-x: hidden;
    }

    .sidebar {
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      width: 220px;
      background-color: #f8f9fa;
      padding-top: 60px;
      border-right: 1px solid #dee2e6;
    }

    .sidebar a {
      padding: 12px 20px;
      display: block;
      color: #333;
      text-decoration: none;
    }

    .sidebar a:hover,
    .sidebar a.active {
      background-color: #007bff;
      color: white;
    }

    .content {
      margin-left: 230px;
      padding: 20px;
    }
  </style>
</head>

<body>
  <div class="sidebar">
    <lord-icon
      src="https://cdn.lordicon.com/nsqneknp.json"
      trigger="loop"
      delay="0"
      stroke="light"
      state="morph-code"
      style="width:100px;height:100px">
    </lord-icon>
    <a href="?page=blog_table" class="d-flex align-items-center gap-1 <?= $page == 'blog_table' ? 'active' : '' ?>">Manage Blogs
      <lord-icon
        src="https://cdn.lordicon.com/joiudcrl.json"
        trigger="in"
        delay="500"
        stroke="light"
        state="in-reveal"
        colors="primary:#121331,secondary:#f24c00,tertiary:#ffffff"
        style="width:30px;height:30px">
      </lord-icon>
    </a>
    <a href="?page=category_table" class="d-flex align-items-center gap-1 <?= $page == 'category_table' ? 'active' : '' ?>">Manage Categories
      <lord-icon
        src="https://cdn.lordicon.com/ogpjkltz.json"
        trigger="in"
        delay="1000"
        stroke="light"
        state="in-reveal"
        colors="primary:#121331,secondary:#c79816"
        style="width:30px;height:30px">
      </lord-icon>
    </a>
    <a href="?page=author_table" class="d-flex align-items-center gap-1 <?= $page == 'author_table' ? 'active' : '' ?>">Manage authors
      <lord-icon
        src="https://cdn.lordicon.com/vwzukuhn.json"
        trigger="in"
        delay="1500"
        stroke="light"
        state="in-reveal"
        colors="primary:#121331,secondary:#3a3347,tertiary:#ffc738,quaternary:#ffffff"
        style="width:30px;height:30px">
      </lord-icon>
    </a>
    <a href="logout.php" class="btn btn-danger w-100 mt-4 d-flex align-items-center justify-content-center gap-1"> <b>Logout</b>
      <lord-icon
        src="https://cdn.lordicon.com/txuhvtae.json"
        trigger="morph"
        stroke="light"
        colors="primary:#121331,secondary:#9cf4a7,tertiary:#c79816,quaternary:#3a3347,quinary:#f24c00,senary:#f9c9c0,septenary:#b26836"
        style="width:40px;height:40px">
      </lord-icon>
    </a>
  </div>

  <div class="content">
    <h3 class="mb-4 d-flex align-items-center">Dashboard <lord-icon
        src="https://cdn.lordicon.com/cqaznhoh.json"
        trigger="loop"
        delay="2000"
        stroke="light"
        style="width:100px;height:60px">
      </lord-icon></h3>
    <?php
    switch ($page) {
      case 'blog_form':
        include "blog_form.php";
        break;
      case 'blog_table':
        include "blog_table.php";
        break;
      case 'category_form':
        include "category_form.php";
        break;
      case 'category_table':
        include "category_table.php";
        break;
      case 'author_form':
        include "author_form.php";
        break;
      case 'author_table':
        include "author_table.php";
        break;
      default:
        include "dashhome.php";
        break;
    }
    ?>
  </div>
  <script src="./ckeditor/ckeditor/ckeditor.js"></script>
  <script src="https://cdn.lordicon.com/lordicon.js"></script>
</body>

</html>