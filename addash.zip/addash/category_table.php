<div class="d-flex justify-content-between mb-4">
  <h4><u><mark>Category table</mark></u></h4>
  <a href="?page=category_form" class="<?= $page == 'category_form' ? 'active' : '' ?>"><button class="btn btn-outline-info d-flex align-items-center px-4"><b>Add</b>
      <lord-icon
        src="https://cdn.lordicon.com/lzsupfwm.json"
        trigger="morph"
        stroke="light"
        colors="primary:#121331,secondary:#ffc738,tertiary:#ffffff"
        style="width:30px;height:30px">
      </lord-icon>
    </button></a>
</div>



<div id="category-table"></div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function loadCategories() {
    $.get('category_ajax.php', {
      action: 'read'
    }, function(data) {
      $('#category-table').html(data);
    });
  }

  function editCategory(id) {
    window.location.href = 'dashboard.php?page=category_form&edit_id=' + id;
  }

  function deleteCategory(id) {
    if (confirm("Delete this category?")) {
      $.post('category_ajax.php', {
        action: 'delete',
        id: id
      }, loadCategories);
    }
  }

  $(document).ready(loadCategories);
</script>