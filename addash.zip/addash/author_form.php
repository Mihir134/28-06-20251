<h4><u>Author <mark>Add/Edit</mark></u></h4>
<form id="author-form">
  <input type="hidden" name="id" id="author-id">

  <input type="text" name="author_Name" class="form-control mb-2" placeholder="Author Name" required>

  <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>

  <input type="tel" name="phone" class="form-control mb-2" placeholder="Phone" required pattern="[0-9]{10,15}">

  <button type="submit" class="btn btn-primary w-100 d-flex justify-content-center fs-3 align-items-center gap-4">Save Author <lord-icon
    src="https://cdn.lordicon.com/opqmrqco.json"
    trigger="in"
    delay="1500"
    state="in-reveal"
    style="width:60px;height:60px">
</lord-icon></button>
</form>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $('#author-form').submit(function(e) {
    e.preventDefault();
    $.post('author_ajax.php', $(this).serialize() + '&action=save', function() {
      $('#author-form')[0].reset();
      $('#author-id').val('');
      window.location.href = 'dashboard.php?page=author_table';
    });
  });

  function fillAuthorForm(author) {
    $('#author-id').val(author.id);
    $('input[name="author_Name"]').val(author.author_Name);
    $('input[name="email"]').val(author.email);
    $('input[name="phone"]').val(author.phone);
  }

  // For edit flow via URL
  <?php if (isset($_GET['edit_id'])): ?>
    $.get('author_ajax.php', {
      action: 'get',
      id: <?= (int)$_GET['edit_id'] ?>
    }, function(data) {
      fillAuthorForm(JSON.parse(data));
    });
  <?php endif; ?>
</script>
