<div class="d-flex justify-content-between mb-4">
  <h4><u><mark>author table</mark></u></h4>
  <a href="?page=author_form" class="<?= $page == 'author_form' ? 'active' : '' ?>"><button class="btn btn-outline-info d-flex align-items-center px-4"><b>Add</b>
      <lord-icon
        src="https://cdn.lordicon.com/lzsupfwm.json"
        trigger="morph"
        stroke="light"
        colors="primary:#121331,secondary:#ffc738,tertiary:#ffffff"
        style="width:30px;height:30px">
      </lord-icon>
    </button></a>
</div>

<div id="author_table"></div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function loadCategories() {
    $.get('author_ajax.php', {
      action: 'read'
    }, function(data) {
      $('#author_table').html(data);
    });
  }

  function editAuth(id) {
    window.location.href = 'dashboard.php?page=author_form&edit_id=' + id;
  }

  function deleteAuth(id) {
    if (confirm("Delete this author?")) {
      $.post('author_ajax.php', {
        action: 'delete',
        id: id
      }, loadCategories);
    }
  }

  $(document).ready(loadCategories);
</script>