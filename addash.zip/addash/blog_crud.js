function loadBlogs() {
  $.get("blog_ajax.php", { action: "read" }, function(data) {
    $("#blog-table").html(data);
  });
}

$("#blog-form").on("submit", function(e) {
  e.preventDefault();
  $.post("blog_ajax.php", $(this).serialize() + '&action=save', function() {
    $("#blog-form")[0].reset();
    $("#blog-id").val('');
    loadBlogs();
  });
});

function editBlog(id) {
  $.get("blog_ajax.php", { action: "get", id: id }, function(data) {
    const blog = JSON.parse(data);
    $("#blog-id").val(blog.id);
    $("input[name='post_title']").val(blog.post_title);
    $("input[name='page_slug']").val(blog.page_slug);
    $("input[name='author']").val(blog.author);
    $("input[name='category']").val(blog.category);
  });
}

function deleteBlog(id) {
  if (confirm("Delete this blog?")) {
    $.post("blog_ajax.php", { action: "delete", id: id }, loadBlogs);
  }
}

$(document).ready(loadBlogs);
