<?php
include "db.php";

$action = $_REQUEST['action'] ?? '';

if ($action === "save") {
  $id = $_POST['id'];
  $title = $_POST['post_title'];
  $slug = $_POST['page_slug'];
  $author = $_POST['author'];
  $cat = $_POST['category'];
  $pagecontent = $_POST['pagecontent'];
  $now = date("Y-m-d H:i:s");

  $imagePath = '';
  if (!empty($_FILES['blogimg']['name'])) {
    $imagePath = "imgUploads/" . time() . '_' . basename($_FILES['blogimg']['name']);
    move_uploaded_file($_FILES['blogimg']['tmp_name'], $imagePath);
  }

  if ($id) {
    // If new image is uploaded, get old image and delete
    if ($imagePath) {
      $getOld = $conn->query("SELECT Img FROM blog WHERE id = $id");
      $oldData = $getOld->fetch_assoc();
      if ($oldData && file_exists($oldData['Img'])) {
        unlink($oldData['Img']);
      }

      $conn->query("UPDATE blog SET post_title='$title', page_slug='$slug', author='$author', category='$cat', Img='$imagePath', pagecontent='$pagecontent', modified_date='$now' WHERE id=$id");
    } else {
      $conn->query("UPDATE blog SET post_title='$title', page_slug='$slug', author='$author', category='$cat', pagecontent='$pagecontent', modified_date='$now' WHERE id=$id");
    }
  } else {
    $conn->query("INSERT INTO blog (post_title, page_slug, author, category, Img, pagecontent, modified_date) VALUES ('$title', '$slug', '$author', '$cat', '$imagePath', '$pagecontent', '$now')");
  }
  exit;
}

if ($action === "read") {
  $res = $conn->query("SELECT * FROM blog");
  echo "
  <table class='table table-bordered text-center'>
    <tr>
      <th>ID</th>
      <th>Title</th>
      <th>Slug</th>
      <th>Author</th>
      <th>Category</th>
      <th>Image</th>
      <th>Page Content</th>
      <th>Actions</th>
    </tr>";
  while ($row = $res->fetch_assoc()) {
    echo "
    <tr>
      <td>{$row['id']}</td>
      <td>{$row['post_title']}</td>
      <td><a href='post.php?slug={$row['page_slug']}' target='_blank'>{$row['page_slug']}</a></td>
      <td>{$row['author']}</td>
      <td>{$row['category']}</td>
      <td><img src='{$row['Img']}' width='100'></td>
      <td>" . substr(strip_tags($row['pagecontent']), 0, 100) . "...</td>
      <td>
        <button class='btn btn-warning btn-sm' onclick='editBlog({$row['id']})'>
          <lord-icon src='https://cdn.lordicon.com/cfkiwvcc.json' trigger='hover' style='width:25px;height:25px'></lord-icon>
        </button>
        <button class='btn btn-danger btn-sm' onclick='deleteBlog({$row['id']})'>
          <lord-icon src='https://cdn.lordicon.com/oqeixref.json' trigger='morph' state='morph-trash-full' style='width:25px;height:25px'></lord-icon>
        </button>
      </td>
    </tr>";
  }
  echo "</table>";
  exit;
}

if ($action === "get") {
  $id = $_GET['id'];
  $res = $conn->query("SELECT * FROM blog WHERE id=$id");
  echo json_encode($res->fetch_assoc());
  exit;
}

if ($action === "delete") {
  $id = $_POST['id'];
  $get = $conn->query("SELECT Img FROM blog WHERE id=$id");
  $row = $get->fetch_assoc();
  if ($row && file_exists($row['Img'])) {
    unlink($row['Img']);
  }
  $conn->query("DELETE FROM blog WHERE id=$id");
  exit;
}
