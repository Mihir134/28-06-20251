<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Stylish Profile Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
  <style>
    body {
      background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
      color: #f1f1f1;
      font-family: 'Segoe UI', sans-serif;
      padding-top: 60px;
    }

    .profile-card {
      background-color: rgba(0, 0, 0, 0.6);
      border-radius: 16px;
      padding: 40px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
    }

    .profile-image-wrapper {
      position: relative;
      width: 160px;
      margin: auto;
    }

    .profile-image {
      width: 160px;
      height: 160px;
      border-radius: 50%;
      border: 4px solid #4caf50;
      object-fit: cover;
      box-shadow: 0 0 25px rgba(76, 175, 80, 0.6);
    }

    .edit-btn {
      position: absolute;
      bottom: 0;
      right: 0;
      background-color: #4caf50;
      color: #fff;
      border-radius: 50%;
      padding: 10px;
      font-size: 14px;
      border: 2px solid #203a43;
      cursor: pointer;
    }

    .info-block {
      padding: 15px 0;
    }

    .info-block p {
      font-size: 1.1rem;
      color: #eee;
      border-bottom: 1px solid #444;
      padding-bottom: 8px;
      margin-bottom: 15px;
    }

    .info-block p strong {
      color: #4caf50;
      width: 130px;
      display: inline-block;
    }

    #editForm {
      display: none;
      margin-top: 20px;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 20px;
      border-radius: 12px;
    }

    #editForm input {
      background-color: #203a43;
      border: 1px solid #4caf50;
      color: #fff;
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="profile-card" id="profileCard">
          <div class="text-center mb-4">
            <div class="profile-image-wrapper" id="profileImageWrapper">
              <img src="https://i.ibb.co/9VjFtPB/avatar.jpg" class="profile-image" alt="Profile Picture">
              <span class="edit-btn" onclick="toggleEditForm()"><i class="fas fa-pen"></i></span>
            </div>
            <h3 class="mt-3">Maria Fernanda</h3>
          </div>
          <div class="row info-block" id="profileDetails">
            <div class="col-md-6">
              <p><strong>First Name:</strong> Maria</p>
              <p><strong>Last Name:</strong> Fernanda</p>
              <p><strong>Email:</strong> maria.fernanda@example.com</p>
            </div>
            <div class="col-md-6">
              <p><strong>Phone No:</strong> +1 234 567 8901</p>
              <p><strong>Address:</strong> 123 Sunset Blvd, Los Angeles, CA 90001</p>
            </div>
          </div>

<form id="editForm" enctype="multipart/form-data">
  <div class="row">
    <div class="col-md-4 text-center">
      <div class="mb-3">
        <label class="form-label d-block">Profile Photo</label>
        <img id="previewImg" src="https://i.ibb.co/9VjFtPB/avatar.jpg" alt="Preview" class="img-thumbnail rounded-circle mb-2" style="width: 150px; height: 150px; object-fit: cover;">
        <input type="file" class="form-control" onchange="previewFile(this)">
      </div>
    </div>
    <div class="col-md-8">
      <div class="row">
        <div class="col-md-6">
          <div class="mb-3">
            <label class="form-label">First Name</label>
            <input type="text" class="form-control" value="Maria">
          </div>
          <div class="mb-3">
            <label class="form-label">Last Name</label>
            <input type="text" class="form-control" value="Fernanda">
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" value="maria.fernanda@example.com">
          </div>
        </div>
        <div class="col-md-6">
          <div class="mb-3">
            <label class="form-label">Phone No</label>
            <input type="text" class="form-control" value="+1 234 567 8901">
          </div>
          <div class="mb-3">
            <label class="form-label">Address</label>
            <input type="text" class="form-control" value="123 Sunset Blvd, Los Angeles, CA 90001">
          </div>
        </div>
      </div>
    </div>
  </div>
  <button type="submit" class="w-100 btn btn-success">Save Changes</button>
</form>
<script>
  function previewFile(input) {
    const file = input.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function (e) {
        document.getElementById('previewImg').src = e.target.result;
      }
      reader.readAsDataURL(file);
    }
  }
</script>

        </div>
      </div>
    </div>
  </div>

  <script>
    function toggleEditForm() {
      const form = document.getElementById('editForm');
      form.style.display = form.style.display === 'none' ? 'block' : 'none';
      gsap.from(form, { opacity: 0, y: 20, duration: 0.5 });
    }

    gsap.from("#profileCard", {
      y: 80,
      opacity: 0,
      duration: 1.4,
      ease: "power4.out"
    });

    gsap.from("#profileImageWrapper", {
      scale: 0,
      duration: 1,
      delay: 0.4,
      ease: "back.out(1.7)"
    });
  </script>
</body>

</html>
