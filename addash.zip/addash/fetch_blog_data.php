<?php
include 'db.php';

$sql = "SELECT * FROM blog ORDER BY created_date DESC";
$result = $conn->query($sql);

$posts = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $posts[] = [
            "post_title" => $row['post_title'],
            "page_slug" => $row['page_slug'],
            "author" => $row['author'],
            "category" => $row['category'],
            "Img" => $row['Img'],
            "pagecontent" => strip_tags($row['pagecontent']), // basic sanitization
        ];
    }
}

header('Content-Type: application/json');
echo json_encode($posts);
?>
