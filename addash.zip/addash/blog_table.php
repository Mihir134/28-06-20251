<div class="d-flex justify-content-between mb-4">
  <h4><u><mark>Blog table</mark></u></h4>
  <a href="?page=blog_form" class="<?= $page == 'blog_form' ? 'active' : '' ?>"><button class="btn btn-outline-info d-flex align-items-center px-4"><b>Add </b>
      <lord-icon
        src="https://cdn.lordicon.com/lzsupfwm.json"
        trigger="morph"
        stroke="light"
        colors="primary:#121331,secondary:#ffc738,tertiary:#ffffff"
        style="width:30px;height:30px">
      </lord-icon>
    </button>
  </a>
</div>

<div id="blog-table"></div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function loadBlogs() {
    $.get('blog_ajax.php', {
      action: 'read'
    }, function(data) {
      $('#blog-table').html(data);
    });
  }

  function editBlog(id) {
    window.location.href = 'dashboard.php?page=blog_form&edit_id=' + id;
  }

  function deleteBlog(id) {
    if (confirm("Delete this blog?")) {
      $.post('blog_ajax.php', {
        action: 'delete',
        id: id
      }, loadBlogs);
    }
  }

  $(document).ready(loadBlogs);
</script>