<?php
$conn = mysqli_connect("localhost", "root", "", "demo");
?>
<h4><u><mark>Add/Edit</mark> Blog</u></h4>
<form id="blog-form">
  <input type="hidden" name="id" id="blog-id">
  <!-- <input type="text" name="post_title" class="form-control mb-2" placeholder="Post Title" required> -->


  <!-- <input type="text" name="page_slug" class="form-control mb-2" placeholder="Page Slug" required> -->

  <input type="text" name="post_title" class="form-control mb-2" id="post_title" placeholder="Enter the post title" required>
  <input type="text" name="page_slug" class="form-control mb-2" id="page_slug" placeholder="Enter the page_slug" required>



  <select name="author" class="form-control mb-2" placeholder="Author" id="" required>
    <?php

    $authdata = mysqli_query($conn, "SELECT * FROM `author`");
    while ($row = mysqli_fetch_assoc($authdata)) {
      echo "<option value='{$row['author_Name']}'>{$row['author_Name']}</option>";
    }

    ?>
  </select>


  <select name="category" class="form-control mb-2" placeholder="Category" id="" required>
    <?php

    $authdata = mysqli_query($conn, "SELECT * FROM `category` WHERE status='Active'");
    while ($row = mysqli_fetch_assoc($authdata)) {
      echo "<option value='{$row['categoryName']}'>{$row['categoryName']}</option>";
    }

    ?>
  </select>

  <input type="file" name="blogimg" class="form-control mb-2 ckeditor">

  <textarea name="pagecontent" id="pagecontent" rows="10" cols="80">
            Type your content here...
  </textarea>

  <button type="submit" class="btn btn-primary w-100 d-flex justify-content-center fs-3 align-items-center gap-4">Save Blog <lord-icon
      src="https://cdn.lordicon.com/opqmrqco.json"
      trigger="in"
      delay="1500"
      state="in-reveal"
      style="width:60px;height:60px">
    </lord-icon></button>
</form>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  function generateSlug(text) {
    return text
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s-]/g, '') 
      .replace(/\s+/g, '-') 
      .replace(/-+/g, '-');
  }

  document.getElementById('post_title').addEventListener('input', function() {
    const slug = generateSlug(this.value);
    document.getElementById('page_slug').value = slug;
  });


  $(document).ready(function() {
    CKEDITOR.replace('pagecontent');

    $('#blog-form').submit(function(e) {
      e.preventDefault();

      // Update CKEditor content
      for (instance in CKEDITOR.instances) {
        CKEDITOR.instances[instance].updateElement();
      }

      const formData = new FormData(this);
      formData.append('action', 'save');

      $.ajax({
        url: 'blog_ajax.php',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        success: function() {
          $('#blog-form')[0].reset();
          $('#blog-id').val('');
          window.location.href = 'dashboard.php?page=blog_table';
        }
      });
    });

    function fillForm(blog) {
      $('#blog-id').val(blog.id);
      $('input[name="post_title"]').val(blog.post_title);
      $('input[name="page_slug"]').val(blog.page_slug);
      $('select[name="author"]').val(blog.author);
      $('select[name="category"]').val(blog.category);
      CKEDITOR.instances['pagecontent'].setData(blog.pagecontent);
    }

    <?php if (isset($_GET['edit_id'])): ?>
      $.get('blog_ajax.php', {
        action: 'get',
        id: <?= (int)$_GET['edit_id'] ?>
      }, function(data) {
        fillForm(JSON.parse(data));
      });
    <?php endif; ?>
  });
</script>