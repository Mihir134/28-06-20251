<?php
include "db.php";
$action = $_REQUEST['action'] ?? '';

if ($action === "save") {
  $id = $_POST['id'];
  $name = $_POST['author_Name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];

  if ($id) {
    $conn->query("UPDATE `author` SET `author_Name`='$name',`email`='$email',`phone`='$phone' WHERE `id`='$id'");
  } else {
    $conn->query("INSERT INTO `author`(`id`, `author_Name`, `email`, `phone`) VALUES (NULL,'$name','$email','$phone')");
  }
  exit;
}

if ($action === "read") {
  $res = $conn->query("SELECT * FROM `author`");
  echo "<table class='table table-bordered text-center'>
    <tr>
        <th>ID</th>
        <th>Author Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Created At</th>
        <th>Actions</th>
    </tr>";
  while ($row = $res->fetch_assoc()) {
    echo "<tr>
      <td>{$row['id']}</td>
      <td>{$row['author_Name']}</td>
      <td>{$row['email']}</td>
      <td>{$row['phone']}</td>
      <td>{$row['created_at']}</td>
      <td>
        <button class='btn btn-warning btn-sm' onclick='editAuth({$row['id']})'>
          <lord-icon src='https://cdn.lordicon.com/cfkiwvcc.json' trigger='hover' style='width:25px;height:25px'></lord-icon>
        </button>
        <button class='btn btn-danger btn-sm' onclick='deleteAuth({$row['id']})'>
          <lord-icon src='https://cdn.lordicon.com/oqeixref.json' trigger='morph' state='morph-trash-full' style='width:25px;height:25px'></lord-icon>
        </button>
      </td>
    </tr>";
  }
  echo "</table>";
  exit;
}

if ($action === "get") {
  $id = $_GET['id'];
  $res = $conn->query("SELECT * FROM author WHERE id=$id");
  echo json_encode($res->fetch_assoc());
  exit;
}

if ($action === "delete") {
  $id = $_POST['id'];
  $conn->query("DELETE FROM author WHERE id=$id");
  exit;
}
?>
