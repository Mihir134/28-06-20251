<?php
include 'db.php';

$slug = $_GET['slug'] ?? '';

if (!$slug) {
    die("Blog slug not specified.");
}

$stmt = $conn->prepare("SELECT * FROM blog WHERE page_slug = ?");
$stmt->bind_param("s", $slug);
$stmt->execute();
$result = $stmt->get_result();
$blog = $result->fetch_assoc();

if (!$blog) {
    die("Blog post not found.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($blog['post_title']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f9f9f9;
            font-family: 'Segoe UI', sans-serif;
        }
        .hero-image {
            width: 100%;
            height: 450px;
            object-fit: cover;
        }
        .blog-header {
            background-color: #fff;
            padding: 40px 20px;
            text-align: center;
            border-bottom: 1px solid #dee2e6;
        }
        .blog-header h1 {
            font-weight: 700;
            font-size: 2.5rem;
            color: #343a40;
        }
        .blog-meta {
            font-size: 0.9rem;
            color: #6c757d;
            margin-top: 10px;
        }
        .blog-content {
            padding: 40px 20px;
            background-color: #fff;
            display: none; /* hidden initially for fade-in */
        }
        .card-section {
            background-color: #ffffff;
            border: 1px solid #dee2e6;
            border-radius: 10px;
            padding: 20px;
            margin-top: 40px;
        }
    </style>
</head>
<body>

    <!-- Hero Image -->
    <div class="blog-wrapper">
        <img src="<?= htmlspecialchars($blog['Img']) ?>" class="hero-image" alt="<?= htmlspecialchars($blog['post_title']) ?>">
    </div>

    <!-- Blog Title & Meta -->
    <div class="blog-header">
        <h1 id="typed-title" data-text="<?= htmlspecialchars($blog['post_title']) ?>"></h1>
        <div class="blog-meta">
            <strong>Author:</strong> <?= htmlspecialchars($blog['author']) ?> |
            <strong>Category:</strong> <?= htmlspecialchars($blog['category']) ?><br>
            <strong>Created:</strong> <?= $blog['created_date'] ?> |
            <strong>Modified:</strong> <?= $blog['modified_date'] ?>
        </div>
    </div>

    <!-- Blog Content -->
    <div class="container-fluid">
        <div class="blog-content" id="blog-content">
            <?= $blog['pagecontent'] ?>
        </div>
    </div>


    <!-- jQuery + Animation Script -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(document).ready(function () {
          // Typing animation
          let title = $('#typed-title').data('text');
          let i = 0;

          function typeWriter() {
              if (i < title.length) {
                  $('#typed-title').append(title.charAt(i));
                  i++;
                  setTimeout(typeWriter, 70);
              } else {
                  // Fade in content after typing is done
                  $('#blog-content').fadeIn(800);
              }
          }

          typeWriter();
      });
    </script>
</body>
</html>
