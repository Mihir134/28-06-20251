<?php
include '../db.php'; // already includes session_start()

$email = $_POST['email'];
$password = $_POST['password'];

$result = $conn->query("SELECT * FROM users WHERE email = '$email'");
if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    if (password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $email;
        echo "success";
    } else {
        echo "Incorrect password";
    }
} else {
    echo "Email not found";
}
