<?php
include '../db.php';

$email = $_POST['email'];
$password = $_POST['password'];

$check = $conn->query("SELECT * FROM users WHERE email = '$email'");
if ($check->num_rows > 0) {
    echo "Email already exists";
} else {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $conn->query("INSERT INTO users (email, password) VALUES ('$email', '$hash')");
    echo "success";
}
?>
