<h4><u>Category <mark>Add/Edit</mark></u></h4>
<form id="category-form">
  <input type="hidden" name="id" id="category-id">
  
  <input type="text" name="categoryName" class="form-control mb-2" placeholder="Category Name" required>
  
  <select name="status" class="form-control mb-2" required>
    <option value="">Select Status</option>
    <option value="Active">Active</option>
    <option value="Inactive">Inactive</option>
  </select>

  <button type="submit" class="btn btn-primary w-100 d-flex justify-content-center fs-3 align-items-center gap-4">Save Category <lord-icon
    src="https://cdn.lordicon.com/opqmrqco.json"
    trigger="in"
    delay="1500"
    state="in-reveal"
    style="width:60px;height:60px">
</lord-icon></button>
</form>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $('#category-form').submit(function(e) {
    e.preventDefault();
    $.post('category_ajax.php', $(this).serialize() + '&action=save', function() {
      $('#category-form')[0].reset();
      $('#category-id').val('');
      window.location.href = 'dashboard.php?page=category_table';
    });
  });

  function fillCategoryForm(category) {
    $('#category-id').val(category.id);
    $('input[name="categoryName"]').val(category.categoryName);
    $('select[name="status"]').val(category.status);
  }

  // For edit flow via URL
  <?php if (isset($_GET['edit_id'])): ?>
    $.get('category_ajax.php', {
      action: 'get',
      id: <?= (int)$_GET['edit_id'] ?>
    }, function(data) {
      fillCategoryForm(JSON.parse(data));
    });
  <?php endif; ?>
</script>
