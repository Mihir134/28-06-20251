<?php
include 'db.php'; // adjust if needed

$output = '';
$search = isset($_POST['query']) ? $conn->real_escape_string($_POST['query']) : '';

$sql = "SELECT * FROM employee 
        WHERE Name LIKE '%$search%' OR Email LIKE '%$search%' 
        ORDER BY Id DESC";

$result = $conn->query($sql);
$sr = 1;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $output .= "
            <tr>
                <td>$sr</td>
                <td>{$row['Name']}</td>
                <td> <img src='{$row['Image']}' alt='UserImg' style='height:100px; width:100px; object-fit:contain;'></td>
                
                <td>{$row['Email']}</td>
            
                <td>
                    <button data-id='{$row['Id']}'>
                    <lord-icon
                        src='https://cdn.lordicon.com/cbtlerlm.json'
                        trigger='click'
                        stroke='bold'
                        state='hover-line'
                        style='width:25px;height:25p'>
                    </lord-icon>
                    </button>
                    <button data-id='{$row['Id']}'>
                        <lord-icon
                            src='https://cdn.lordicon.com/sxhqklqh.json'
                            trigger='morph'
                            stroke='bold'
                            state='morph-trash-in'
                            colors='primary:#121331,secondary:#4bb3fd,tertiary:#e83a30,quaternary:#ebe6ef'
                            style='width:25px;height:25px'>
                        </lord-icon>
                    </button>
                </td>
            </tr>
        ";
        $sr++;
    }
} else {
    $output = "<tr><td colspan='5' class='text-center text-danger'>No records found</td></tr>";
}

echo $output;
