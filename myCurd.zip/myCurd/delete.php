<?php
include 'db.php';

$data = stripslashes(file_get_contents("php://input"));
$mydata = json_decode($data, true);
$sid = $mydata['sid'];

if (!empty($sid)) {
    // Step 1: Get image path from DB
    $imgQuery = "SELECT Image FROM `employee` WHERE Id='$sid'";
    $imgResult = $conn->query($imgQuery);

    if ($imgResult->num_rows > 0) {
        $row = $imgResult->fetch_assoc();
        $imgPath = $row['Image'];

        // Step 2: Delete image file from server if it exists
        if (file_exists($imgPath)) {
            unlink($imgPath);
        }
    }

    // Step 3: Delete the record
    $sql = "DELETE FROM `employee` WHERE Id='$sid'";
    if ($conn->query($sql) === TRUE) {
        echo json_encode([
            "status" => "success",
            "message" => "Employee deleted successfully!"
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Currently unable to delete record."
        ]);
    }
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Id is not defined. Unable to delete."
    ]);
}
?>

<?php
// include 'db.php';
//     $data = stripslashes(file_get_contents("php://input"));
//     $mydata = json_decode($data, true);

//     $sid = $mydata['sid'];


//     if(!empty($sid)){
//         $sql = "DELETE FROM `employee` WHERE Id='$sid'";
//         if($conn->query($sql) == true){
//             echo json_encode([
//                 "status" => "success",
//                 "message" => "Employee Deleted successfully!"
//             ]);
//         }else{
//             echo json_encode([
//                 "status" => "error",
//                 "message" => "Currently unable to delete"
//             ]);
//         }
//     }else{
//         echo json_encode([
//                 "status" => "error",
//                 "message" => "Id is not definded Unable to Delete"
//             ]);
//     }

?>