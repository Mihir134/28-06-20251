const table = document.getElementById("scheduleTable");

  table.addEventListener("mouseover", function (e) {
    const col = e.target.getAttribute("data-col");
    if (!col) return;
    document.querySelectorAll(`[data-col='${col}']`).forEach(cell => cell.classList.add("hover-col"));
    const th = table.querySelector(`thead th[data-col='${col}']`);
    if (th) th.classList.add("hover-head");
  });

  table.addEventListener("mouseout", function (e) {
    const col = e.target.getAttribute("data-col");
    if (!col) return;
    document.querySelectorAll(`[data-col='${col}']`).forEach(cell => cell.classList.remove("hover-col"));
    const th = table.querySelector(`thead th[data-col='${col}']`);
    if (th) th.classList.remove("hover-head");
  });