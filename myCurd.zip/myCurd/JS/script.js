
$(document).ready(function () {
function initializeDataTable() {
    $('#scheduleTable').DataTable({
        pageLength: 5,
        lengthMenu: [5, 10, 25, 50, 100],
        destroy: true, // important to reinitialize
        ordering: true,
        info: true,
        paging: true
    });
}


    // select data form the database 
    function showdata() {
    $.ajax({
        url: "retrive.php",
        method: "GET",
        dataType: "json",
        success: function (data) {
            let output = "";
            if (Array.isArray(data) && data.length > 0) {
                data.forEach(item => {
                    output += `<tr>
                        <td>${item.Id}</td>
                        <td>${item.Name}</td>
                        <td><img src="${item.Image}" style="height:100px; width:100px; object-fit:contain;"></td>
                        <td>${item.Email}</td>
                        <td>
                            <button class="btn btn-edit" data-sid="${item.Id}">
                                     <lord-icon
                                         src="https://cdn.lordicon.com/cbtlerlm.json"
                                        trigger="click"
                                         stroke="bold"
                                         state="hover-line"
                                         style="width:25px;height:25px">
                                     </lord-icon>
                                 </button>
                                 <button class="btn btn-del" data-sid="${item.Id}"> 
                                     <lord-icon
                                         src="https://cdn.lordicon.com/sxhqklqh.json"
                                        trigger="morph"
                                    stroke="bold"
                                    state="morph-trash-in"
                                       colors="primary:#121331,secondary:#4bb3fd,tertiary:#e83a30,quaternary:#ebe6ef"
                                       style="width:25px;height:25px">
                                    </lord-icon>
                              </button>
                        </td>
                    </tr>`;
                });
            } else {
                output = "<tr><td colspan='5'>No record available.</td></tr>";
            }

            // Clear previous DataTable if exists
            if ($.fn.DataTable.isDataTable('#scheduleTable')) {
                $('#scheduleTable').DataTable().destroy();
            }

            $('#tbody').html(output);
            initializeDataTable();
        }
    });
}
    
 
    // }
    showdata()

    // Ajex Request for Insert Data
    $("#btnadd").click(function (e) {
       
    e.preventDefault();

    let EId = $("#EmpId").val();
    let nm = $("#EmpName").val();
    let em = $("#EmpEmail").val();
    let pw = $("#EmpPassword").val();
    let imgFile = $("#EmpImg")[0].files[0]; // Get actual file

    let formData = new FormData();
    formData.append("   ", EId);
    formData.append("name", nm);
    formData.append("email", em);
    formData.append("password", pw);
    formData.append("image", imgFile); // Important!

    $.ajax({
        url: "insert.php",
        method: "POST",
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            const res = typeof response === "string" ? JSON.parse(response) : response;

            $("#toastMsg").text(res.message);
            const toastElement = document.getElementById("liveToast");
            toastElement.classList.remove("text-bg-success", "text-bg-danger");

            if (res.status === "success") {
                toastElement.classList.add("text-bg-success");
                $("#myform")[0].reset();
                showdata();
            } else {
                toastElement.classList.add("text-bg-danger");
            }

            const toast = new bootstrap.Toast(toastElement);
            toast.show();
        }
    });
});



    // delete code 
    $("tbody").on("click", ".btn-del", function () {
        let id = $(this).attr("data-sid");
        if (!confirm("Are you sure you want to delete this?")) {
            return;
        }
        console.log("delted is click ", id)
        mydata = { sid: id };
        mythis = this;
        $.ajax({
            url: "delete.php",
            method: "POST",
            data: JSON.stringify(mydata),
            success: function (data) {
                console.log(data);
                const res = typeof data === "string" ? JSON.parse(data) : data;
                $("#toastMsg").text(res.message);
                const toastElement = document.getElementById("liveToast");
                toastElement.classList.remove("text-bg-success", "text-bg-danger", "text-bg-primary");
                if (res.status === "success") {
                    toastElement.classList.add("text-bg-success");
                    $("#myform")[0].reset();
                    // showdata();
                    $(mythis).closest("tr").fadeOut()

                } else {
                    toastElement.classList.add("text-bg-danger");
                }
                const toast = new bootstrap.Toast(toastElement);
                toast.show();
            },
        });
    });

    // edit the data

    $("tbody").on("click", ".btn-edit", function () {
        let id = $(this).attr("data-sid");
        console.log("Edit this", id)
        mydata = { sid: id };

        $.ajax({
            url: "edit.php",
            method: "POST",
            dataType: "json",
            data: JSON.stringify(mydata),
            success: function(data){
                // console.log(data);

                $("#EmpId").val(data.Id);
                $("#EmpName").val(data.Name);
                // $("#EmpImg").val(data.Image);
                $("#EmpEmail").val(data.Email);
                $("#EmpPassword").val(data.Password);
            },
        });


    });


    // Live Search
    $('#searchBox').on('keyup', function () {
        let keyword = $(this).val();

        $.ajax({
            url: 'search.php',
            method: 'POST',
            data: { query: keyword },
            success: function (data) {
                $('#tbody').html(data); // update table rows
            }
        });
    });

    // Optionally: trigger once on page load to fill initial data
    $('#searchBox').trigger('keyup');


});
