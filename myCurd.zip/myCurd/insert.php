<?php
include 'db.php';

// For debugging (optional)
ini_set('display_errors', 1);
error_reporting(E_ALL);
header("Content-Type: application/json");

// Collect POST data
$id = $_POST['id'] ?? '';
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Check if file is uploaded
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $imageTmp = $_FILES['image']['tmp_name'];
    $imageName = time() . '_' . basename($_FILES['image']['name']);
    $targetDir = "uploads/";
    $targetFile = $targetDir . $imageName;

    // Validate image extension
    $imageType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($imageType, $allowed)) {
        echo json_encode(["status" => "error", "message" => "Only JPG, JPEG, PNG, and GIF allowed."]);
        exit;
    }

    // Upload the image
    if (!move_uploaded_file($imageTmp, $targetFile)) {
        echo json_encode(["status" => "error", "message" => "Failed to upload image."]);
        exit;
    }
} else {
    echo json_encode(["status" => "error", "message" => "All Fields Requrird!"]);
    exit;
}

// Insert or update in DB
if (!empty($name) && !empty($email) && !empty($password)) {
    $sql = "INSERT INTO `employee`(`Id`, `Name`, `Email`, `Image`, `Password`) 
            VALUES ('$id','$name','$email','$targetFile', '$password') 
            ON DUPLICATE KEY UPDATE 
                `Name`='$name',
                `Email`='$email', 
                `Image`='$targetFile', 
                `Password`='$password'";

    if ($conn->query($sql) === TRUE) {
        echo json_encode([
            "status" => "success",
            "message" => "Friend '$name' successfully managed!"
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Database error: " . $conn->error
        ]);
    }
} else {
    echo json_encode([
        "status" => "error",
        "message" => "All fields are required."
    ]);
}
?>


<?php
// include 'db.php';

// $data = stripslashes(file_get_contents("php://input"));
// $mydata = json_decode($data, true);

// $id = $mydata['id'];
// $name = $mydata['name'];
// $email = $mydata['email'];
// $password = $mydata['password'];


// $imageName = time() . '_' . basename($_FILES['image']['name']);
// $targetDir = "uploads/";
// $targetFile = $targetDir . $imageName;

// // File validation (optional)
// $imageType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
// $allowed = ['jpg', 'jpeg', 'png', 'gif'];
// if (!in_array($imageType, $allowed)) {
//     echo json_encode(["status" => "error", "message" => "Only JPG, JPEG, PNG, and GIF allowed."]);
//     exit;
// }

// if (!move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
//     echo json_encode(["status" => "error", "message" => "Failed to upload image."]);
//     exit;
// }


// inset data 
// if (!empty($name) && !empty($email) && !empty($password)) {
//     $sql = "INSERT INTO `employee`(`Name`, `Email`, `Password`) VALUES ('$name','$email','$password')";
//     if ($conn->query($sql) == TRUE) {
//         echo json_encode([
//             "status" => "success",
//             "message" => "Employee '$name' added successfully!"
//         ]);
//     } else {
//         echo json_encode([
//         "status" => "error",
//         "message" => "Unable to store the data."
//     ]);


//     }
// } else {
//     echo json_encode([
//         "status" => "error",
//         "message" => "All fields are required."
//     ]);
// }



//inset/ update data 
// if (!empty($name) && !empty($email) && !empty($password)) {
//     $sql = "INSERT INTO `employee`(`Id`, `Name`, `Email`, `Image`, `Password`) VALUES ('$id','$name','$email','$targetFile', '$password') ON DUPLICATE KEY UPDATE `Name`='$name',`Email`='$email', `Image`= '$targetFile', `Password`='$password'";
//     if ($conn->query($sql) == TRUE) {
//         echo json_encode([
//             "status" => "success",
//             "message" => "Friend '$name' successfully managed!"
//         ]);
//     } else {
//         echo json_encode([
//             "status" => "error",
//             "message" => "Unable to store the data."
//         ]);
//     }
// } else {
//     echo json_encode([
//         "status" => "error",
//         "message" => "All fields are required."
//     ]);
// }
