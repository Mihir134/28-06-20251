<?php
    include 'db.php';

    $select = "SELECT * FROM `employee`";
    $result = $conn->query($select);
    if($result->num_rows>0){
        $data = array();
        while($row = $result->fetch_assoc()){
            $data[]=$row;
        }
    }

    echo json_encode($data);

?>