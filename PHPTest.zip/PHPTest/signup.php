<?php
require "head.php";
?>
<div class="container mt-5">
    <h1 class="text-center">Registration</h1>
    <form class="row g-3 w-50 m-auto" id="signupform">


        <div class="col-md-12">
            <label for="Username" class="form-label">Username</label>
            <input type="text" class="form-control" id="Username">
        </div>
        <div class="col-md-12">
            <label for="Email" class="form-label">Email</label>
            <input type="email" class="form-control" id="Email">
        </div>
        <div class="col-md-12">
            <label for="Password" class="form-label">Password</label>
            <input type="password" class="form-control" id="Password">
        </div>
        <p id="slerror"></p>
        <div class="col-12">
            <button type="submit" id="register" class="btn btn-primary w-100">Register</button>
        </div>
        <p>Already have an account? <a href="login.php">Log in</a></p>
    </form>

</div>
<?php
require "footer.php"
?>