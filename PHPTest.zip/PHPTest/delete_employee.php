<?php
require "db.php";
 
 
 
$id = $_POST['id'];
 
$sql = "DELETE FROM `employee` WHERE Id = $id";
 
if ($conn->query($sql) === TRUE) {
    echo "Deleted";
} else {
    echo "Error: " . $conn->error;
}
 
$conn->close();
?>