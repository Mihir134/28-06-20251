  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/script.js"></script>
  
</body>
</html>
