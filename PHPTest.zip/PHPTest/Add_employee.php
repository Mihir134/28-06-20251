<?php
require "db.php";

$FirstName1 = str_replace(" "," ",$_POST['FirstName']);
$FirstName = $FirstName1;
$LastName1 = str_replace(" "," ",$_POST['LastName']);
$LastName = $LastName1;



$fullName = $FirstName . " " . $LastName;

$Emailemp = $_POST['Emailemp'];
$phone = $_POST['phone'];
$post = $_POST['post'];
$empId = $_POST['empId'] ?? '';

$PhotoName = '';



if (isset($_FILES['Photo']) && $_FILES['Photo']['error'] == 0) {
    $PhotoName = "image/" . basename($_FILES['Photo']['name']);
    move_uploaded_file($_FILES['Photo']['tmp_name'], $PhotoName);
}

if ($FirstName == "" || $LastName == "" || $Emailemp == "" || $phone == "" || $post == "") {
    echo "All Field requred";
}

if ($empId == "") {
    $sql = mysqli_query($conn, "INSERT INTO `employee`(`Avatar`, `Name`, `Email`, `Post`, `Phone`) VALUES ('$PhotoName','$fullName','$Emailemp','$post','$phone')");
} else {
    $sql = mysqli_query($conn, "UPDATE `employee` SET `Avatar`='$PhotoName', `Name`='$fullName', `Email`='$Emailemp', `Post`='$post', `Phone`='$phone' WHERE `Id`='$empId'");
}

if ($sql) {
    echo json_encode(["success" => "true"]);
} else {
    echo json_encode(["success" => "false", "message" => "Database error"]);
}
