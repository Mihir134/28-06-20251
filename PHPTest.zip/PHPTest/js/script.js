

$(document).ready(function () {
    // $("#slerror").text("heapodjf");


    $("#signupform").on("submit", function (e) {
        e.preventDefault();

        let Username = $("#Username").val();
        let Email = $("#Email").val();
        let Password = $("#Password").val();

        let formData = new FormData();

        formData.append("Username", Username);
        formData.append("Email", Email);
        formData.append("Password", Password);

        $.ajax({
            type: "POST",
            url: "signup_process.php",
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {

                try {
                    let res = JSON.parse(response);  

                    if (res.success === "true") {
                        window.location.href = "login.php";
                    } else {
                        $("#slerror").text("Signup failed.");
                    }
                } catch (e) {
                    $("#slerror").text(response);
                }
            }
        });
    })

    $("#loginform").on("submit", function (e) {
        e.preventDefault();
        let Username = $("#Username").val();
        let Password = $("#Password").val();

        let formData = new FormData();

        formData.append("Username", Username);
        formData.append("Password", Password);


        $.ajax({
            type: "POST",
            url: "login_process.php",
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {

                try {
                    let res = JSON.parse(response);  

                    if (res.success === "true") {
                        window.location.href = "homepage.php";
                    } else {
                        $("#slerror").text("Signup failed.");
                    }
                } catch (e) {
                    $("#slerror").text(response);
                }
            }
        });
    })

    // insert data
    $("#AddempForm").on("submit", function (e) {
        e.preventDefault();

        let empId = $("#empId").val(); 
        let FirstName = $("#FirstName").val();
        let LastName = $("#LastName").val();
        let Emailemp = $("#Emailemp").val();
        let phone = $("#phone").val();
        let post = $("#post").val();
        let Photo = $("#Photo")[0].files[0];

        let formData = new FormData();
        formData.append("empId", empId); 
        formData.append("FirstName", FirstName);
        formData.append("LastName", LastName);
        formData.append("Emailemp", Emailemp);
        formData.append("phone", phone);
        formData.append("post", post);
        formData.append("Photo", Photo);

        $.ajax({
            type: "POST",
            url: "Add_employee.php",
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                $('#staticBackdrop').modal('hide');
                empdata();
                $("#AddempForm").get(0).reset();
            }
        });
    });



    function empdata() {
    $.ajax({
        url: "retrive_employee.php",
        method: "GET",
        dataType: "html",
        success: function (response) {            
            if ($.fn.DataTable.isDataTable("#employeeTable")) {
                $("#employeeTable").DataTable().destroy();
            }
            $("#RetriveEmp").html(response);
            $("#employeeTable").DataTable({
                pageLength: 5,
                lengthMenu: [5, 10, 25, 50],
                order: [[0, 'asc']],
                columnDefs: [{ orderable: false, targets: [1, 6] }]
            });
        }
    });
}

    empdata();


    // edit emp data 
    $(document).on("click", ".Update-employee", function () {
        let id = $(this).data("eid");

        $.ajax({
            url: "get_single_employee.php",
            type: "POST",
            data: { id: id },
            dataType: "json",
            success: function (res) {
                let empdataname = res.Name;
                const NameAry = empdataname.split(" ");
                $("#empId").val(res.Id);
                $("#FirstName").val(NameAry[0]);
                $("#LastName").val(NameAry[1]);
                $("#Emailemp").val(res.Email);
                $("#phone").val(res.Phone);
                $("#post").val(res.Post);
                let modal = new bootstrap.Modal(document.getElementById('staticBackdrop'));
                modal.show();
                empdata();
            }
        });
    });

    // delete    
    $(document).on('click', '.Delete-employee', function () {
        var id = $(this).data('eid');

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'delete_employee.php',
                    type: 'POST',
                    data: { id: id },
                    success: function (response) {
                        empdata();
                        alert("heiad;");
                        // if (response.trim() === "Deleted") {
                        //     Swal.fire(
                        //         'Deleted!',
                        //         'Employee has been removed.',
                        //         'success'
                        //     );
                            
                        // } else {
                        //     Swal.fire('Error!', response, 'error');
                        // }
                    }
                });
            }
        });
    });


    

});