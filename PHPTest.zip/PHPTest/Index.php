<?php
require "head.php";
?>

<body>
    <nav class="navbar bg-body-tertiary">
        <div class="container-fluid container">
            <a class="navbar-brand"><b>Manage Employees</b></a>

            <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><b>Add New Employee</b></button>

            <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="staticBackdropLabel">Modal title</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="AddempForm" class="row g-3">
                                <p id="#slerror1">asdfsdfsadfsdf</p>
                                <input type="hidden" id="empId">

                                <div class="col-md-6">
                                    <label for="FirstName" class="form-label">First Name</label>
                                    <input type="text" class="form-control" id="FirstName">
                                </div>
                                <div class="col-md-6">
                                    <label for="LastName" class="form-label">Last Name</label>
                                    <input type="text" class="form-control" id="LastName">
                                </div>
                                <div class="col-md-12">
                                    <label for="Email" class="form-label">Email</label>
                                    <input type="Email" class="form-control" id="Emailemp">
                                </div>
                                <div class="col-md-12">
                                    <label for="phone" class="form-label">Phone</label>
                                    <input type="number" class="form-control" id="phone">
                                </div>


                                <div class="col-md-12">
                                    <label for="post" class="form-label">Post</label>
                                    <select id="post" class="form-select">
                                        <option selected>Choose...</option>
                                        <option>Manager</option>
                                        <option>Owner</option>
                                        <option>Marketer</option>
                                        <option>Developer</option>
                                        <option>Hr</option>
                                    </select>
                                </div>
                                <div class="col-md-12">
                                    <label for="Photo" class="form-label">Select Avatar</label>
                                    <input type="file" class="form-control" id="Photo">
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Insert/Update</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </nav>

    <div class="container mt-5">
        <table class="table table-striped table-hover" id="employeeTable">
            <thead class="text-center">
                <tr>
                    <th>ID</th>
                    <th>Avatar</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Post</th>
                    <th>Phone</th>
                    <th>Action</th> 
                </tr>
            </thead>

            <tbody class="text-center" id="RetriveEmp">
                <tr>
                    <td colspan="7" class="loadinganimation">
                        <span class="loader"></span>
                    </td>

                </tr>
            </tbody>
        </table>
    </div>

    <?php
    require "footer.php"
    ?>