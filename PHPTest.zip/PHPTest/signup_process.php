<?php
    require "db.php";

    // echo print_r($_POST);

    $Username = $_POST['Username'];
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];

    if($Username == "" || $Email == "" || $Password == ""){
        echo "All Field are Required";
        die;
    }

    $varifypastdata =  mysqli_query($conn, "SELECT * FROM `user` WHERE `Username`='$Username' or `Email`='$Email'");

    if(mysqli_num_rows($varifypastdata)>=1){
        echo "Data already taken ";
        die;
    }else{
        $sql = mysqli_query($conn, "INSERT INTO `user`(`Username`, `Email`, `Password`) VALUES ('$Username','$Email','$Password')");
        if($sql){
            echo json_encode(["success"=> "true"]);
        }else{
            echo "error";
        }
    }
?>