<?php
    require "db.php";

    $id = $_POST['id'];
    $sql = mysqli_query($conn, "SELECT * FROM employee WHERE Id = '$id'");
    $data = mysqli_fetch_assoc($sql);
    echo json_encode($data);
?>