<?php
require "head.php";
?>
<div class="container mt-5">
    <h1 class="text-center">Login</h1>
    <form id="loginform" class="row g-3 w-50 m-auto">


        <div class="col-md-12">
            <label for="Username" class="form-label">Username</label>
            <input type="text" class="form-control" id="Username">
        </div>
        <div class="col-md-12">
            <label for="Password" class="form-label">Password</label>
            <input type="password" class="form-control" id="Password">
        </div>
        <p id="slerror"></p>
        
        <div class="col-12">
            <button type="submit" id="register" class="btn btn-primary w-100">Login</button>
        </div>
        <p>Don't have account <a href="signup.php">registaer now</a></p>
    </form>

</div>
<?php
require "footer.php"
?>