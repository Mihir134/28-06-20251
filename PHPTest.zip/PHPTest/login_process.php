<?php
    require "db.php";

    // echo print_r($_POST);

    $Username = $_POST['Username'];
    $Password = $_POST['Password'];

    if($Username == "" || $Password == ""){
        echo "All Field are Required";
        die;
    }

    $varifypastdata =  mysqli_query($conn, "SELECT * FROM `user` WHERE `Username`='$Username' and `Password` = '$Password'");

    if(mysqli_num_rows($varifypastdata)==1){
        
        echo json_encode(["success"=> "true"]);

        die;
    }else{
       echo "user not found";
    }
?>