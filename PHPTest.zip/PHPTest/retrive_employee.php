<?php
require "db.php";

$sql = mysqli_query($conn, "SELECT * FROM `employee`");

if (mysqli_num_rows($sql) > 0) {
    while ($row = mysqli_fetch_assoc($sql)) {
        $avatar = $row['Avatar'] !== "" ? $row['Avatar'] : "image/arrow.png";


        echo "<tr>
            <td>{$row['Id']}</td>
            <td><img src='{$avatar}' alt='Avatar'></td>

            <td>{$row['Name']}</td>
            <td>{$row['Email']}</td>
            <td>{$row['Post']}</td>
            <td>{$row['Phone']}</td>
            <td>
                <button class='Update-employee btn btn-sm btn-primary' data-eid='{$row['Id']}'>
                    <i class='fa-solid fa-file-pen'></i>
                </button>
                <button class='Delete-employee btn btn-sm btn-danger' data-eid='{$row['Id']}'>
                    <i class='fa-solid fa-trash'></i>
                </button>
            </td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='7' class='text-center'>No employee data found.</td></tr>";
}
